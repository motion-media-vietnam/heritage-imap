import { distanceKm } from './explore.ts';
import type { Place } from '../data/places.ts';

export function nearbyDestinations(place: Place, all: Place[], limit = 3) {
  return all.filter(candidate => candidate.slug !== place.slug)
    .map(candidate => ({ place: candidate, km: distanceKm(place.coordinates, candidate.coordinates) }))
    .sort((a, b) => a.km - b.km).slice(0, limit);
}

// Selection survives closing the sheet. Filtering never silently changes the map camera.
export function selectDestination(current: string | undefined, next: string, visible: Set<string>) {
  return visible.has(next) ? next : current;
}
export function sheetHeight(start: number, deltaY: number, viewport: number) {
  return Math.min(viewport * .85, Math.max(160, start - deltaY));
}

// No destination-specific, rights-cleared 90-second videos have been verified.
// Do not populate this with a general city overview or inferred YouTube IDs.
export const dedicatedVideos: Record<string, { url: string; durationSeconds: number }> = {};
export const practicalInformation: Record<string, { text: string; source: string; checked: string }> = {
  'van-mieu': {
    text: 'Tham quan ban ngày: 08:00–17:00, tất cả các ngày. Chương trình buổi tối có lịch và vé riêng. Kiểm tra lại với di tích trước khi đến.',
    source: 'https://vanmieu.gov.vn/en', checked: '2026-10-17',
  },
};
