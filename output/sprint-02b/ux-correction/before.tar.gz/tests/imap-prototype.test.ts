import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { places } from '../src/data/places.ts';
import { nearbyDestinations, selectDestination, sheetHeight, dedicatedVideos, practicalInformation } from '../src/lib/imap-prototype.ts';

test('selection is synchronized through one slug and rejects filtered destinations', () => {
  assert.equal(selectDestination(undefined, 'pho-co', new Set(['pho-co'])), 'pho-co');
  assert.equal(selectDestination('pho-co', 'van-mieu', new Set(['pho-co'])), 'pho-co');
});
test('nearby destinations exclude self and sort straight-line distances', () => {
  for (const place of places) {
    const nearby = nearbyDestinations(place, places);
    assert.equal(nearby.length, 3);
    assert(nearby.every(candidate => candidate.place.slug !== place.slug));
    assert(nearby.every((candidate, i) => i === 0 || candidate.km >= nearby[i - 1].km));
  }
});
test('sheet drag clamps expanded and collapsed heights', () => {
  assert.equal(sheetHeight(400, -900, 800), 680);
  assert.equal(sheetHeight(400, 900, 800), 160);
  assert.equal(sheetHeight(400, 50, 800), 350);
});
test('unverified videos are absent and practical facts carry primary source and verification date', () => {
  assert.equal(Object.keys(dedicatedVideos).length, 0);
  assert.equal(practicalInformation['van-mieu'].source, 'https://vanmieu.gov.vn/en');
  assert.match(practicalInformation['van-mieu'].checked, /^\d{4}-\d{2}-\d{2}$/);
});
test('isolated route does not import approved Heritage or production map and preserves OSM fix', () => {
  const route = readFileSync(new URL('../src/pages/imap-prototype.astro', import.meta.url), 'utf8');
  const script = readFileSync(new URL('../src/scripts/imap-prototype.ts', import.meta.url), 'utf8');
  assert(!route.includes('HeritageChoice'));
  assert(!route.includes('MapExplorer'));
  assert(!route.includes('youtube.com/embed'));
  assert.match(script, /referrerPolicy: 'strict-origin-when-cross-origin'/);
  assert.match(script, /https:\/\/tile.openstreetmap.org\/\{z\}\/\{x\}\/\{y\}.png/);
  assert(!script.includes('window.location'));
  assert.match(script, /invalidateSize\(\{ pan: false \}\)/);
});
