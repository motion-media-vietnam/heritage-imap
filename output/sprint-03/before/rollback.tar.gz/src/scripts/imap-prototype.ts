import { places, demoLocation, type Category } from '../data/places';
import { districtPlaceSlugs } from '../data/districts';
import { findPlaces } from '../lib/explore';
import { selectDestination, filterPrototypeDestinations, sheetStates, sheetStateHeight, nearestSheetState, videoSelectionSheetState, type SheetState } from '../lib/imap-prototype';
import type * as Leaflet from 'leaflet';

const explorer = document.querySelector<HTMLElement>('#prototype-explorer')!;
const search = document.querySelector<HTMLInputElement>('#prototype-search')!;
const categorySelect = document.querySelector<HTMLSelectElement>('#prototype-category')!;
const districtSelect = document.querySelector<HTMLSelectElement>('#prototype-district')!;
const sheet = document.querySelector<HTMLElement>('#prototype-sheet')!;
const story = document.querySelector<HTMLElement>('#prototype-story')!;
const storyLabel = document.querySelector<HTMLElement>('#prototype-story-label')!;
const content = document.querySelector<HTMLElement>('#prototype-story-content')!;
const status = document.querySelector<HTMLElement>('#prototype-map-status')!;
const reopen = document.querySelector<HTMLButtonElement>('#prototype-reopen')!;
const close = document.querySelector<HTMLButtonElement>('#prototype-close')!;
const handle = document.querySelector<HTMLElement>('#sheet-handle')!;
const stateButtons = Array.from(document.querySelectorAll<HTMLButtonElement>('button[data-sheet-state]'));
const districtOptions = Array.from(districtSelect.querySelectorAll<HTMLOptionElement>('[data-district-option]'));
const templates = new Map(Array.from(document.querySelectorAll<HTMLTemplateElement>('[data-prototype-story]')).map(template => [template.dataset.prototypeStory!, template]));
const directory = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-select-place]'));
const markers = new Map<string, Leaflet.Marker>();
const mobile = window.matchMedia('(max-width: 960px)');
let map: Leaflet.Map | undefined;
let selected: string | undefined;
let category: Category | 'All' = 'All';
let visible = new Set(places.map(place => place.slug));
let previousFocus: HTMLElement | null = null;
let sheetState: SheetState = 'collapsed';
let drag: { id: number; startY: number; height: number } | undefined;

function availableHeight() { return explorer.getBoundingClientRect().height; }
function paintSheetHeight(height: number) {
  sheet.style.setProperty('--sheet-height', `${height}px`);
  explorer.style.setProperty('--sheet-overlay-height', `${height}px`);
}
function setSheetState(next: SheetState) {
  sheetState = next;
  sheet.dataset.sheetState = next;
  explorer.dataset.sheetState = next;
  sheet.classList.remove('is-dragging');
  paintSheetHeight(sheetStateHeight(next, availableHeight()));
  content.inert = mobile.matches && next === 'collapsed';
  for (const button of stateButtons) button.setAttribute('aria-pressed', String(button.dataset.sheetState === next));
}
function syncSelection() {
  for (const button of directory) button.setAttribute('aria-pressed', String(button.dataset.selectPlace === selected));
  for (const [slug, marker] of markers) {
    marker.getElement()?.classList.toggle('is-selected', selected === slug);
    marker.getElement()?.setAttribute('aria-pressed', String(selected === slug));
    marker.setZIndexOffset(selected === slug ? 500 : 0);
  }
}
function stopVideo() {
  content.querySelectorAll('video').forEach(video => { video.pause(); video.removeAttribute('src'); video.load(); });
  content.replaceChildren();
}
function openPlace(slug: string, trigger?: HTMLElement) {
  const next = selectDestination(selected, slug, visible);
  const place = places.find(candidate => candidate.slug === slug);
  if (next !== slug || !place || !templates.has(slug)) return;
  if (story.hidden) previousFocus = trigger ?? (document.activeElement instanceof HTMLElement ? document.activeElement : null);
  stopVideo();
  selected = slug;
  content.append(templates.get(slug)!.content.cloneNode(true));
  // No shared overview or autoplay; future dedicated videos still need approval.
  content.querySelectorAll('video').forEach(video => { video.autoplay = false; });
  storyLabel.textContent = place.name;
  story.hidden = false;
  explorer.classList.add('has-story');
  reopen.hidden = true;
  content.scrollTop = 0;
  filter();
  let openingState: SheetState = sheetState === 'expanded' ? 'expanded' : 'half';
  if (mobile.matches && openingState !== 'expanded') {
    const frame = content.querySelector<HTMLElement>('[data-destination-video]');
    const toolbar = story.querySelector<HTMLElement>('.story-toolbar');
    if (frame && toolbar) {
      const required = handle.getBoundingClientRect().height + toolbar.getBoundingClientRect().height
        + frame.getBoundingClientRect().bottom - content.getBoundingClientRect().top + 12;
      openingState = videoSelectionSheetState(required, availableHeight());
    }
  }
  setSheetState(openingState);
  content.querySelector<HTMLElement>('h2')?.focus({ preventScroll: true });
}
function closeStory(restoreFocus = true) {
  stopVideo();
  story.hidden = true;
  explorer.classList.remove('has-story');
  reopen.hidden = !selected;
  // Selected pin and the map's geographic camera survive closing the panel.
  setSheetState('collapsed');
  if (restoreFocus) {
    const target = previousFocus?.isConnected && previousFocus.getClientRects().length ? previousFocus
      : !reopen.hidden ? reopen : categorySelect;
    target.focus({ preventScroll: true });
  }
}
function filter() {
  const candidates = findPlaces(places, search.value, category, demoLocation);
  for (const option of districtOptions) {
    const slugs = districtPlaceSlugs[option.value] ?? [];
    const count = candidates.filter(place => slugs.includes(place.slug)).length;
    // Preserve an explicitly selected empty filter so users can understand/reset it.
    option.hidden = count === 0 && districtSelect.value !== option.value;
    option.textContent = `${option.value} · ${count}`;
  }
  visible = new Set(filterPrototypeDestinations(places, search.value, category, districtSelect.value).map(place => place.slug));
  for (const button of directory) button.closest<HTMLElement>('li')!.hidden = !visible.has(button.dataset.selectPlace!);
  for (const [slug, marker] of markers) {
    if (!map) continue;
    if (visible.has(slug) && !map.hasLayer(marker)) marker.addTo(map);
    if (!visible.has(slug) && map.hasLayer(marker)) marker.remove();
  }
  if (selected && !visible.has(selected)) {
    closeStory(false);
    selected = undefined;
    reopen.hidden = true;
  }
  document.querySelector('#prototype-count')!.textContent = `${visible.size} địa điểm`;
  document.querySelector<HTMLElement>('#prototype-empty')!.hidden = visible.size !== 0;
  content.querySelectorAll<HTMLButtonElement>('[data-nearby-place]').forEach(button => {
    button.disabled = !visible.has(button.dataset.nearbyPlace!);
    button.title = button.disabled ? 'Địa điểm ngoài bộ lọc hiện tại' : '';
  });
  syncSelection();
}
for (const button of directory) button.addEventListener('click', () => openPlace(button.dataset.selectPlace!, button));
content.addEventListener('click', event => {
  const button = event.target instanceof Element ? event.target.closest<HTMLButtonElement>('[data-nearby-place]') : null;
  if (button && !button.disabled) openPlace(button.dataset.nearbyPlace!);
});
close.addEventListener('click', () => closeStory());
reopen.addEventListener('click', () => { if (selected) openPlace(selected, reopen); });
document.addEventListener('keydown', event => {
  if (event.key !== 'Escape') return;
  // Let native fullscreen consume Escape without tearing down its story/player.
  const fullscreenVideo = content.querySelector<HTMLVideoElement & { webkitDisplayingFullscreen?: boolean }>('video');
  if (document.fullscreenElement || fullscreenVideo?.webkitDisplayingFullscreen) return;
  if (!story.hidden) closeStory();
  else if (mobile.matches && sheetState !== 'collapsed') {
    setSheetState('collapsed');
    stateButtons[0]?.focus({ preventScroll: true });
  }
});
document.querySelector<HTMLAnchorElement>('.skip')?.addEventListener('click', event => {
  event.preventDefault();
  if (mobile.matches) { closeStory(false); setSheetState('half'); }
  document.querySelector<HTMLElement>('#prototype-directory')?.focus({ preventScroll: true });
});
search.addEventListener('input', filter);
categorySelect.addEventListener('change', () => { category = categorySelect.value as Category | 'All'; filter(); });
districtSelect.addEventListener('change', filter);
for (const button of stateButtons) button.addEventListener('click', () => {
  const state = button.dataset.sheetState as SheetState;
  if (sheetStates.includes(state)) setSheetState(state);
});
handle.addEventListener('pointerdown', event => {
  if (!mobile.matches || event.button !== 0 || (event.target instanceof Element && event.target.closest('button'))) return;
  drag = { id: event.pointerId, startY: event.clientY, height: sheet.getBoundingClientRect().height };
  handle.setPointerCapture(event.pointerId);
  sheet.classList.add('is-dragging');
  content.inert = false;
});
handle.addEventListener('pointermove', event => {
  if (!drag || drag.id !== event.pointerId) return;
  const available = availableHeight();
  paintSheetHeight(Math.max(sheetStateHeight('collapsed', available), Math.min(sheetStateHeight('expanded', available), drag.height + drag.startY - event.clientY)));
});
function endDrag(event: PointerEvent) {
  if (!drag || event.pointerId !== drag.id) return;
  if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
  drag = undefined;
  setSheetState(nearestSheetState(sheet.getBoundingClientRect().height, availableHeight()));
}
handle.addEventListener('pointerup', endDrag);
handle.addEventListener('pointercancel', endDrag);
window.addEventListener('resize', () => setSheetState(sheetState));
mobile.addEventListener('change', () => setSheetState(sheetState));

function resetView() {
  map?.fitBounds(places.map(place => [place.coordinates.lat, place.coordinates.lng] as Leaflet.LatLngTuple), { padding: [48, 48], maxZoom: 14 });
}
document.querySelector('#prototype-reset')!.addEventListener('click', resetView);
async function connect() {
  try {
    const L = await import('leaflet');
    map = L.map('prototype-map', { scrollWheelZoom: false, zoomControl: false });
    L.control.zoom({ position: 'topright', zoomInTitle: 'Phóng to', zoomOutTitle: 'Thu nhỏ' }).addTo(map);
    const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      referrerPolicy: 'strict-origin-when-cross-origin',
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>',
    });
    tiles.on('tileload', () => { status.textContent = 'Chọn ghim để mở câu chuyện · Kéo để khám phá'; });
    tiles.on('tileerror', () => { status.textContent = 'Một phần nền bản đồ chưa tải được. Ghim và danh sách vẫn hoạt động.'; });
    resetView();
    places.forEach((place, index) => {
      const pin = document.createElement('span'); pin.className = 'curated-pin'; pin.textContent = String(index + 1).padStart(2, '0');
      const label = document.createElement('span'); label.textContent = place.name;
      const marker = L.marker([place.coordinates.lat, place.coordinates.lng], {
        title: place.name, icon: L.divIcon({ className: 'curated-icon', html: pin, iconSize: [42, 42], iconAnchor: [21, 21] }),
      }).bindTooltip(label, { direction: 'top' });
      marker.on('click', () => openPlace(place.slug, marker.getElement()));
      marker.on('add', () => { marker.getElement()?.setAttribute('aria-label', `Mở câu chuyện ${place.name}`); syncSelection(); });
      markers.set(place.slug, marker); marker.addTo(map!);
    });
    tiles.addTo(map);
    const observer = new ResizeObserver(() => {
      // Preserve geographic camera while desktop columns resize; mobile sheet is an overlay.
      if (!map) return;
      const center = map.getCenter(); const zoom = map.getZoom();
      map.invalidateSize({ pan: false }); map.setView(center, zoom, { animate: false });
    });
    observer.observe(document.querySelector('#prototype-map')!);
    window.addEventListener('pagehide', event => {
      content.querySelectorAll('video').forEach(video => video.pause());
      if (!event.persisted) { observer.disconnect(); stopVideo(); map?.remove(); map = undefined; }
    });
    filter();
  } catch {
    status.textContent = 'Không tải được bản đồ. Chọn địa điểm trong danh sách để tiếp tục.';
  }
}
filter(); setSheetState('collapsed'); void connect();
