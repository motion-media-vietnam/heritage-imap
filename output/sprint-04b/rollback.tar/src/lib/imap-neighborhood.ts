/** Sprint 04A prototype-only discovery helpers. No production records are changed. */
import { demoLocation, type Coordinates, type Place } from '../data/places.ts';
import { districtPlaceSlugs } from '../data/districts.ts';
import { distanceKm, normalize } from './explore.ts';

export const discoveryCategories = [
  { id: 'landmark', label: 'Di sản & tham quan' },
  { id: 'utensils', label: 'Ẩm thực & nhà hàng' },
  { id: 'coffee', label: 'Cà phê & trà' },
  { id: 'theater', label: 'Biểu diễn & văn hóa' },
  { id: 'bed', label: 'Khách sạn & lưu trú' },
] as const;
export type DiscoveryCategory = typeof discoveryCategories[number]['id'];
export type DiscoveryRadius = 500 | 1000 | 2000 | 'All';
// Future approved prototype records can use the five discovery categories
// without falsely inheriting a production sample's sightseeing category.
export type DiscoveryPlace = Omit<Place, 'category'> & {
  category: Place['category'] | DiscoveryCategory;
  discoveryCategory?: DiscoveryCategory;
};
export interface NeighborhoodState {
  center: Coordinates;
  radius: DiscoveryRadius;
  query: string;
  category: DiscoveryCategory | 'All';
  district: string;
}
export function createNeighborhoodState(): NeighborhoodState {
  return { center: { ...demoLocation }, radius: 1000, query: '', category: 'All', district: 'All' };
}
export function parseDiscoveryRadius(value: string): DiscoveryRadius {
  return value === 'All' ? 'All' : value === '500' ? 500 : value === '2000' ? 2000 : 1000;
}
export function markerCategory(place: DiscoveryPlace): DiscoveryCategory {
  // The current six records are all sightseeing/heritage. Other categories stay empty.
  if (place.discoveryCategory) return place.discoveryCategory;
  return discoveryCategories.some(category => category.id === place.category) ? place.category as DiscoveryCategory : 'landmark';
}
export function filterNeighborhoodPlaces(all: DiscoveryPlace[], state: NeighborhoodState): DiscoveryPlace[] {
  const districts = state.district === 'All' ? undefined : new Set(districtPlaceSlugs[state.district] ?? []);
  const terms = normalize(state.query).trim().split(/\s+/).filter(Boolean);
  return all.filter(place => {
    const category = markerCategory(place);
    const label = discoveryCategories.find(item => item.id === category)!.label;
    const searchable = normalize([place.name, place.vietnamese, place.category, label, place.area, place.description].join(' '));
    return terms.every(term => searchable.includes(term))
      && (state.category === 'All' || category === state.category)
      && (!districts || districts.has(place.slug))
      && (state.radius === 'All' || distanceKm(state.center, place.coordinates) * 1000 <= state.radius);
  }).sort((a, b) => distanceKm(state.center, a.coordinates) - distanceKm(state.center, b.coordinates));
}
export function validDiscoveryCenter(center: Coordinates) {
  return Number.isFinite(center.lat) && Number.isFinite(center.lng)
    && Math.abs(center.lat) <= 90 && Math.abs(center.lng) <= 180;
}
export type DiscoveryLocationResult = { kind: 'success'; center: Coordinates } | { kind: 'denied' | 'error' };
export function resolveDiscoveryLocation(state: NeighborhoodState, result: DiscoveryLocationResult): NeighborhoodState {
  if (result.kind !== 'success' || !validDiscoveryCenter(result.center)) return state;
  return { ...state, center: { ...result.center } };
}
export function offerDiscoveryArea(center: Coordinates, camera: Coordinates) {
  return validDiscoveryCenter(camera) && distanceKm(center, camera) >= .1;
}

/** Pixel-space connected components: nearby tap targets become one accessible list entry.
 * No geographic points are generated, moved or persisted. No arbitrary marker-count cap.
 */
export function clusterProjectedPoints<T extends { id: string; x: number; y: number }>(points: readonly T[], separation = 56): T[][] {
  if (!Number.isFinite(separation) || separation <= 0) throw new RangeError('Positive marker separation required');
  const parents = points.map((_, index) => index);
  const find = (index: number): number => {
    while (parents[index] !== index) { parents[index] = parents[parents[index]!]!; index = parents[index]!; }
    return index;
  };
  const cells = new Map<string, number[]>();
  points.forEach((point, index) => {
    const x = Math.floor(point.x / separation); const y = Math.floor(point.y / separation);
    for (let dx = -1; dx <= 1; dx++) for (let dy = -1; dy <= 1; dy++) {
      for (const neighbor of cells.get(`${x + dx}:${y + dy}`) ?? []) {
        const other = points[neighbor]!;
        if (Math.hypot(point.x - other.x, point.y - other.y) < separation) parents[find(index)] = find(neighbor);
      }
    }
    const key = `${x}:${y}`; const cell = cells.get(key) ?? []; cell.push(index); cells.set(key, cell);
  });
  const groups = new Map<number, T[]>();
  points.forEach((point, index) => { const key = find(index); const group = groups.get(key) ?? []; group.push(point); groups.set(key, group); });
  return Array.from(groups.values());
}

const categoryPaths: Record<DiscoveryCategory, string> = {
  landmark: 'M3 10h18L12 3 3 10Zm2 2v7m5-7v7m4-7v7m5-7v7M3 21h18',
  utensils: 'M4 3v6a3 3 0 0 0 6 0V3M7 3v18M19 3c-4 3-4 8 0 9v9m0-18v9',
  coffee: 'M4 8h13v8a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4V8Zm13 1h2a3 3 0 0 1 0 6h-2M7 2v3m5-3v3M2 22h18',
  theater: 'M3 4c4 2 7 2 11 0v6c0 5-8 8-11 0V4Zm3 4h1m3 0h1m-5 4c2 2 3 2 5 0M16 8l5-2v8c0 4-4 7-7 5m2-8h1m1 4h1',
  bed: 'M3 4v17m18-12v12M3 17h18M3 9h18v8H3V9Zm3 0V6h5v3m2 0V6h5v3',
};
export function categoryIconPath(category: DiscoveryCategory) { return categoryPaths[category]; }
export function categoryIconSvg(category: DiscoveryCategory) {
  // Static trusted paths only; names/record data are never interpolated as HTML.
  return `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false"><path d="${categoryPaths[category]}"/></svg>`;
}
