// Editorial demo content, not a record of previously published monthly selections.
// Update the explicit issue dates and approved videos together for each new edition.
export const currentHeritageChoice = {
  month: 'Tháng 10, 2026',
  issue: '2026-10',
  title: 'Hà Nội — nơi ký ức gặp nhịp sống hôm nay',
  summary: 'Theo chân nghệ sĩ Nga Phạm qua những góc phố thân quen, khám phá một Hà Nội dung hòa nét xưa và sức sống mới. Một lời mời đi chậm, lắng nghe và nhìn thành phố qua câu chuyện của người địa phương.',
  videoId: '2CxNZtrFedo',
  href: 'https://vietnam.travel/things-to-do/my-hanoi',
};

// Most recent first. These are sample issue dates, not video publication dates.
export const pastHeritageChoices = [
  {
    month: 'Tháng 9, 2026',
    issue: '2026-09',
    title: 'Huế — những câu chuyện bên dòng Hương',
    videoId: 'Sige0y8XxeU',
    href: 'https://vietnam.travel/things-to-do/my-hue',
  },
  {
    month: 'Tháng 8, 2026',
    issue: '2026-08',
    title: 'Văn Miếu — khám phá di sản khi đêm xuống',
    videoId: '-jVXCHcCoiw',
    href: '/places/van-mieu/',
  },
];
