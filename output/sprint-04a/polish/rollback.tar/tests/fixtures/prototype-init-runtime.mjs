// Controlled Leaflet lifecycle fixture, not a DOM renderer/browser/network test.
// Real Map.addLayer/whenReady and Circle projection/getBounds are preserved.
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import { places } from '../../src/data/places.ts';
import { createNeighborhoodState, filterNeighborhoodPlaces } from '../../src/lib/imap-neighborhood.ts';

const node = () => ({ style: {}, firstChild: { namespaceURI: 'http://www.w3.org/2000/svg' }, getContext() {}, createSVGRect() {} });
const document = { documentElement: { style: {} }, createElement: node, createElementNS: node, addEventListener() {}, removeEventListener() {} };
const exports = {};
runInNewContext(readFileSync(new URL('../../node_modules/leaflet/dist/leaflet-src.js', import.meta.url), 'utf8'), {
  exports, module: { exports }, document,
  navigator: { userAgent: 'MyHanoi controlled Leaflet lifecycle test', platform: 'Linux' },
  window: { document, screen: {}, devicePixelRatio: 1, addEventListener() {}, removeEventListener() {} },
  setTimeout, clearTimeout, console,
});
const real = exports;

/**
 * @param {string} controller
 * @param {{width?: number, height?: number, radius?: import('../../src/lib/imap-neighborhood.ts').DiscoveryRadius}} [options]
 */
export async function probePrototypeInitialization(controller, options = {}) {
  const width = options.width ?? 960; const height = options.height ?? 640;
  const portion = (start, end) => controller.slice(controller.indexOf(start), controller.indexOf(end));
  const functions = portion('function updateCircle()', 'function resetView()')
    + portion('async function connect()', "on(retry, 'click'").replace("await import('leaflet')", 'await loadLeaflet()');
  const evidence = { leafletVersion: real.version, browserVerified: false, errors: /** @type {string[]} */ ([]), tileLayerAdds: 0,
    markerCandidates: /** @type {string[]} */ ([]), filterCalls: 0, fitCalls: 0, viewCalls: 0, container: { x: width, y: height },
    fittedBounds: /** @type {Array<{lat: number, lng: number}>} */ ([]), status: '', retryOffered: false, initializationCompleted: false };
  const renderer = { options: { tolerance: 0 }, _initPath() {}, _addPath() {}, _updateCircle() {}, _removePath() {} };
  function makeMap() {
    // Deliberately unloaded, as after L.map(element, {zoomControl:false}).
    const map = Object.create(real.Map.prototype);
    Object.assign(map, {
      options: { crs: real.CRS.EPSG3857 }, _layers: {}, _zoomBoundLayers: {}, _loaded: false,
      _container: { clientWidth: width, clientHeight: height }, _mapPane: { _leaflet_pos: real.point(0, 0) },
      getRenderer() { return renderer; },
      setView(center, zoom) {
        evidence.viewCalls++; this._zoom = zoom; this._loaded = true;
        this._pixelOrigin = this.project(center).subtract(this.getSize().divideBy(2)).round();
        this.fire('load'); return this;
      },
      fitBounds(bounds) {
        evidence.fitCalls++; evidence.fittedBounds = [bounds.getSouthWest(), bounds.getNorthEast()]; return this;
      },
      remove() { this._layers = {}; this._loaded = false; return this; },
    });
    const size = map.getSize(); evidence.container = { x: size.x, y: size.y };
    return map;
  }
  const context = {
    lifetime: { disposed: false }, connecting: false, map: undefined, L: undefined,
    radiusCircle: undefined, tiles: undefined, loadingTimeout: undefined,
    state: { ...createNeighborhoodState(), radius: options.radius ?? 1000 }, allowAreaOffer: false, exploreArea: { hidden: true },
    retry: { hidden: true }, status: { textContent: '' }, setTimeout, clearTimeout,
    console: { error: (...args) => evidence.errors.push(String(args[1]?.stack || args[1] || args[0])) },
    clearMarkers() {}, renderMarkers() {}, updateAreaOffer() {},
    filter() { evidence.filterCalls++; evidence.markerCandidates = filterNeighborhoodPlaces(places, context.state).map(place => place.slug); },
    async loadLeaflet() {
      return { ...real, map: makeMap, control: { zoom: () => ({ addTo() {} }) },
        tileLayer: () => ({ on() {}, off() {}, addTo() { evidence.tileLayerAdds++; } }),
      };
    },
  };
  await runInNewContext(`${functions}\nconnect();`, context, { timeout: 3000 });
  evidence.status = context.status.textContent; evidence.retryOffered = !context.retry.hidden;
  evidence.initializationCompleted = evidence.tileLayerAdds === 1 && evidence.filterCalls === 1 && evidence.errors.length === 0;
  return evidence;
}
