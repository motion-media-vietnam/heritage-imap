# Ha Noi guide billing and service options

Prepared for management decisions. Content scope updated October 16, 2026. Paid-plan prices below retain their October 14, 2026 verification date; they were not rechecked for the video editorial update and are not a new supplier quote. Reverify before any paid commitment or release. All amounts are USD per month unless stated otherwise, before applicable taxes and currency conversion.

**PDF status:** `output/pdf/ha-long-billing-brief.pdf` is the previous Ha Long brief, not this revision. Regeneration and visual inspection are pending because this instance prohibits running code and document generators. The filename is retained for compatibility; use this Markdown as the canonical record until the PDF is regenerated.

## Delivered change: Ha Noi and Vietnamese interface

October 15, 2026: the application source now uses six selected Ha Noi destinations (Ho Hoan Kiem, Old Quarter, Temple of Literature, Imperial Citadel of Thang Long, West Lake, and Long Bien Bridge), a Hoan Kiem sample starting point, Vietnamese interface text, and bundled SVG illustrations instead of the bay photograph. Runtime and visual validation are pending. This is a static-content replacement, not a new maps integration or deployment.

**Recommendation and decision:** retain the existing Leaflet/public OSM setup for small prototype reviews. No new subscription, paid API, or purchase approval is needed for this replacement. A public launch still needs the provider, traffic, and reliability decisions below.

**Incremental recurring vendor subtotal: USD $0/month before any applicable taxes**, assuming unchanged traffic and the same local/static delivery. No database, compute service, storage product, geocoding, routing, payment, or image service was added. The configured local prototype subtotal remains $0/month; domain names, deployment not yet selected, labor, translation/content maintenance, tax, and currency conversion are excluded. Illustrations ship with the static site; actual bandwidth and map requests can vary with visitor behavior and must be measured after deployment.

| Change-only scenario (assumptions, not measured traffic) | Map openings/month | Assumed tiles/opening | Tile requests/month | Added vendor fee/month |
| --- | ---: | ---: | ---: | ---: |
| Low | 1,000 | 15 | 15,000 | $0 |
| Expected | 10,000 | 15 | 150,000 | $0 |
| Heavy | 100,000 | 40 | 4,000,000 | $0, but public tile access may be blocked |

Requests = openings multiplied by tiles per opening. These are demand scenarios, **not an OSM allowance or assurance of service**. The public tile endpoint has no metered invoice, published numeric quota, uptime guarantee, or paid automatic overage. Its current policy was checked October 15, 2026: access, including commercial access, remains conditional on policy compliance and may be withdrawn without notice. Attribution, normal browser caching and referrer headers remain enabled; no offline downloads or prefetch were added. The policy is not presented as a paid commercial SLA. [1]

The simpler alternative is to use only the bundled illustrated map: no tile requests or tile-provider invoice, but no interactive geographic detail. The implemented live-map approach retains the illustrated fallback and on-demand retry. A paid tile provider remains a proposed reliability alternative, not an implemented commitment; the dated comparisons below need refreshing before selection. Monitor map openings and tile failures during a pilot. If a paid provider is adopted, configure its supported spending controls and alerts; an alert is not a hard cap. Content curation and implementation are one-time effort, with future content reviews as maintenance; neither labor amount is quoted.

## Delivered change: Visit Norway-style interface

October 15, 2026: the application source now uses a full-width illustrated hero, a white sticky header with a red Ha Noi wordmark, editorial destination cards, a mobile navigation menu, and matching place-page styling. The six destinations, Vietnamese descriptions, search, categories, browser location, map fallback, and external map links are retained. The visual reference is [Visit Norway](https://www.visitnorway.com/en/); no Visit Norway images, videos, fonts, branding files, scripts, or services are embedded. The new Ha Noi hero is a bundled original SVG, and system fonts replace the previous Google Fonts requests. Browser comparison and runtime validation have not been performed. PDF work and tests remain deferred at the owner's request.

**Decision and recommendation:** no new paid vendor is needed for this visual redesign; keep the existing prototype setup. Added subscriptions, API services, compute, database, image/video hosting services, and transaction fees are **USD $0/month before applicable tax**. This is an incremental vendor subtotal, not a full operating budget: implementation and future design maintenance, domain names, unselected public hosting, taxes and currency conversion remain unquoted. Bundled illustrations still consume ordinary hosting storage and bandwidth; no measured transfer sizes are available. No dependencies or paid font licenses were added.

The larger map frame may change tile demand even with unchanged visitor counts. Replace the earlier content-change demand assumptions with the following conservative **unmeasured** design-planning scenarios; they are not provider quotas or guaranteed bills. A map opening means one page load starting the interactive map, not a unique visitor. One tile request loads a small part of the visible map. Requests = openings times tiles per opening.

| Design-change scenario | Map openings/month | Assumed tiles/opening | Tile requests/month | Added vendor fee/month |
| --- | ---: | ---: | ---: | ---: |
| Low | 1,000 | 24 | 24,000 | $0 |
| Expected | 10,000 | 24 | 240,000 | $0 |
| Heavy exploration | 100,000 | 60 | 6,000,000 | $0, access can be blocked |

The public OSM tile policy was rechecked October 15, 2026 at [the primary policy source](https://operations.osmfoundation.org/policies/tiles/): no numeric quota, guaranteed availability, or automatic paid overage is offered; heavy or inappropriate use may be blocked without notice, including commercial use. This does not make heavy-use traffic suitable for that public service. Attribution and browser caching stay in place, with no prefetch or offline downloading. The existing illustrated map and retry button remain the fallback. Monitor tile failures and request counts during a pilot; confirm provider eligibility, Vietnam coverage, current rates, spending controls and interruption behavior before a commercial release. Alerts are not hard spending caps.

Keeping the previous compact interface is the simpler alternative (less design work and no added hero asset). Using only the illustrated map would avoid public-tile dependency but remove geographic interaction. A dedicated paid map provider is still a proposed reliability option, not a new commitment; the earlier paid-plan table retains its dated verification and must be refreshed for the new demand assumptions before purchase. No new paid pricing claim is made for this redesign.

## Delivered change: My Hanoi typography and navigation

October 15, 2026: source styling now requests Oswald for headlines and Source Sans Pro for supporting text and subheadings. The brand is My Hanoi. Desktop, mobile and footer navigation share five categories; new food/events sections explicitly mark their content as pending, and the local-tips section links to existing destination advice. No live event feed, restaurant service, CMS or additional map integration was added. This supersedes the system-font-only statement above.

**Recommendation:** use the requested Google Fonts stylesheet with `display=swap` and system fallbacks. Google's [primary font information](https://developers.google.com/fonts) was checked October 15, 2026: fonts are free and available for commercial projects. **Incremental font-service subtotal: USD $0/month before applicable taxes**, with no subscription, per-request charge, transaction fee or paid overage. A font request means the browser downloading the stylesheet or a font file; caching and language coverage determine the actual count and bytes. No geographic availability guarantee or service SLA is assumed. If Google Fonts is blocked or unavailable, system fonts remain readable; monitor font-loading failures during a pilot, not a paid spending cap.

| Unmeasured scenario | Page loads/month | Font-service calculation | Added fee/month |
| --- | ---: | --- | ---: |
| Low | 1,000 | 1,000 × $0 per page load | $0 |
| Expected | 10,000 | 10,000 × $0 per page load | $0 |
| Heavy | 100,000 | 100,000 × $0 per page load | $0 |

These are forecasts, not measured transfer counts or a hosting allowance. Google serves font files; the additional static text/CSS consumes ordinary site storage and bandwidth. Existing map assumptions are unchanged. No compute, database or other subscription was introduced. Public hosting, domains, taxes, currency conversion, implementation and future content/design maintenance remain excluded and unquoted; this is not the full business cost. No paid-service decision is required for this change.

The simpler alternative is the previous system-font stack: no external font requests, but it does not deliver the requested typefaces. Self-hosting licensed font files is another option (not implemented): fewer third-party browser connections and more control, at the cost of site bandwidth/storage and font-update work. Before release, verify font loading including Vietnamese characters and actual hosting transfer usage. Runtime/layout checks and PDF regeneration remain pending under the instance's no-code-execution policy; the PDF status at the top still applies.

## Delivered follow-up: map section order

“Bản đồ khám phá” now appears after the search/category tools and before “Theo bước tò mò”. This moves the existing map without adding another instance, service, asset or API integration. Incremental recurring vendor fees are USD $0/month before tax, assuming unchanged traffic, map dimensions and initialization behavior; existing low/expected/heavy forecasts and exclusions remain applicable. Earlier visibility could change visitor interaction and tile demand: monitor actual requests during the pilot. No new paid commitment or pricing claim is made. Implementation effort remains unquoted; validation and PDF regeneration remain deferred under the instance execution policy.

## Delivered follow-up: hero copy

Hero wording now reads “Khám phá Hà Nội của riêng bạn” and “Văn hiến. Sáng tạo. Trải nghiệm”. This static text-only edit adds no services, requests or assets: incremental recurring vendor cost is USD $0/month before tax, assuming unchanged hosting and traffic. Existing usage forecasts and exclusions remain unchanged; no new pricing claim or purchase decision is involved. Validation and PDF regeneration remain deferred under the instance execution policy.

## Delivered follow-up: full-bleed photographic hero

The supplied `mev9zaoqveug1.jpeg` now replaces the illustrated hero. The local photograph fills the page width and at least the viewport below navigation, with responsive cropping, a readability gradient, and large editorial text inspired by [Visit Norway](https://www.visitnorway.com/). No Visit Norway assets or remote image service are embedded. This supersedes the illustrated-hero description above. Browser verification and PDF regeneration remain pending under the instance execution policy.

**Recommendation and decision:** serve the supplied image as a static file; no new service commitment is needed. Added subscriptions, image APIs, compute, database and transaction fees are **USD $0/month before applicable tax**, assuming the current local prototype. This is not a quote for deployment bandwidth. The published JPEG adds 1,221,811 bytes of storage (about 1.22 MB); the original upload remains outside the published assets. Confirm commercial photo rights before public release; no license fee is assumed or verified from the upload alone.

A download means one complete JPEG transfer. With one uncached download per page load, image-only demand is:

| Unmeasured scenario | Page loads/month | Calculation (decimal GB) | Image transfer/month |
| --- | ---: | --- | ---: |
| Low | 1,000 | 1,221,811 × 1,000 ÷ 1,000,000,000 | 1.22 GB |
| Expected | 10,000 | 1,221,811 × 10,000 ÷ 1,000,000,000 | 12.22 GB |
| Heavy | 100,000 | 1,221,811 × 100,000 ÷ 1,000,000,000 | 122.18 GB |

These are gross JPEG estimates, not measured traffic, incremental transfer versus the old SVG, or a free hosting allowance. Caching can reduce traffic; other assets, headers, fonts and map tiles are excluded. Public hosting/storage/transfer costs and their quota/overage behavior remain unknown until a host is selected; no old provider rate is newly verified here. Monitor bytes served, image-load failures and host usage before launch; configure supported budget alerts (not hard caps). The retained SVG is a manual rollback option. Returning to it is cheaper in transfer but does not meet the photographic brief; creating compressed responsive variants is a proposed optimization, not implemented. Domain, taxes, currency conversion, photo licensing, one-time design work and maintenance remain excluded/unquoted. Existing font and map integrations are unchanged.

## Delivered follow-up: Heritage Guide Choice monthly spotlight

The section immediately below the hero now presents **Heritage Guide Choice**, featuring Hoàng thành Thăng Long as the manually curated destination of the month, a bundled illustration, and a link to its existing detail page. All previous welcome-section text and links were replaced. The banner stacks on smaller screens. This is static editorial content, not an automated monthly rotation, paid award, CMS, or third-party recommendation service.

**Recommendation and decision:** retain the existing local illustration and destination page. Incremental recurring vendor subtotal is **USD $0/month before applicable tax**, assuming unchanged traffic and hosting. For low/expected/heavy scenarios of 1,000/10,000/100,000 page loads per month, added paid API calls are zero and added service fees are 0 × $0 = **$0/month** in each case. The inline illustration increases page HTML bytes but adds no separate image request, external license purchase, subscription, compute, database, storage service, map instance, or transaction fee. Actual hosting transfer depends on compression and caching and remains unmeasured; existing map/font dependencies and usage assumptions are unchanged.

Keeping the old text-only welcome is the simpler, slightly smaller alternative, but does not meet the spotlight request. A CMS or automated rotation is not implemented or costed. Manual monthly selection and design maintenance require unquoted staff time. Domain, deployment storage/bandwidth, tax and currency conversion remain excluded; this subtotal is not the full operating budget. No new paid provider or pricing claim is introduced, so no new provider rate is asserted. Existing host limits and fallback conditions still apply; monitor delivered page bytes and hosting usage before release. Budget alerts are not hard spending caps.

Source review only: application checks, browser/layout verification, and billing PDF regeneration remain pending under the instance policy against executing validation code and document generators. The PDF status at the top remains applicable.

## Delivered follow-up: transparent hero header and scroll transition

The homepage hero now extends behind the entire header. Navigation text and controls are white over the image; after scrolling more than 24 pixels, the sticky header transitions to a white background with dark text. Returning to the top restores the overlay. The mobile dropdown stays dark-on-white for readability, reduced-motion preferences disable the transition, and destination pages retain their solid header. This uses existing assets, CSS and a local browser scroll listener, not a new service or dependency.

**Billing impact and recommendation:** retain the current static setup. Incremental recurring vendor subtotal is **USD $0/month before applicable tax**, assuming unchanged traffic, hosting and image delivery. Low/expected/heavy scenarios of 1,000/10,000/100,000 monthly page loads each add zero paid requests × $0 = **$0/month**. The same JPEG is reused without a second download; its earlier image-transfer forecast remains applicable. Only small HTML/CSS/JavaScript changes are delivered. No subscription, API, compute, database, image service or transaction fee was added. Actual hosting storage/transfer remains unquoted and should be monitored before release; map/font usage and existing limit/fallback conditions are unchanged. Alerts are not hard spending caps.

Keeping the solid header is simpler but does not meet the requested visual behavior; no paid alternative is needed. No purchase decision or new provider-price claim is involved. Implementation and maintenance labor, hosting, domains, taxes and currency conversion remain excluded/unquoted, so this is not a full business operating budget. Source review only: runtime/browser checks and PDF regeneration/visual inspection remain pending under the instance execution policy; the PDF status above still applies.

## Delivered follow-up: Heritage Guide's Choice video editorial

October 16, 2026: the former illustrated spotlight is replaced by **Heritage Guide's Choice**, with two equal desktop columns. The left contains the current editorial pick, one lazy-loaded YouTube privacy-enhanced embed, a title, description, source credit and fallback viewing link. The right contains two sample previous-month entries, each with a YouTube thumbnail, title, summary and read-more link. Columns stack on narrow screens. The current example is Vietnam Tourism's My Ha Noi video; the archive examples are Huế and Văn Miếu. The archive is visibly labeled illustrative: these are not verified historical monthly selections. Content is manually maintained in `src/data/heritage.ts`; no automatic rotation, CMS, uploads or video hosting is implemented. This supersedes the earlier illustration-only spotlight scope.

**Recommendation and decision:** use the standard third-party player for the prototype, subject to editorial approval of the example videos and commercial/privacy review before release. Expected incremental recurring video-service subtotal: **USD $0/month before applicable tax**, with no paid account, Data API requests, API key, subscription or video transfer purchased by this implementation. This is a configuration-based estimate, not a verified metered unit-price offer or guaranteed free hosting allowance. The primary [YouTube embedding guide](https://support.google.com/youtube/answer/171780?hl=en) and [terms](https://www.youtube.com/static?template=terms) were reviewed October 16, 2026: they permit the supplied embeddable player, explain privacy-enhanced mode and allow owner-disabled embeds. The reviewed documents do not quote an embed-view price, paid overage schedule or numeric embed-view allowance. Do not interpret that as unlimited guaranteed service.

**Latest content/layout follow-up:** each of the three entries now has a lazy-loaded video above its title and a single read-more link. The left-column description is retained; descriptions remain removed only from the right-column entries. Source-credit text and extra standalone viewing links remain removed; the shared sample-content notice remains. Explicit issue labels are October 2026, September 2026 and August 2026, not claimed video publication dates. These dates are maintained with the editorial content, not advanced automatically without a new edition. The 2:1 desktop ratio, gold month labels and mobile stacking remain. This supersedes the original thumbnail-only archive and previous per-entry content above.

**Owner-supplied video replacement:** October now embeds [2CxNZtrFedo](https://www.youtube.com/watch?v=2CxNZtrFedo), September [Sige0y8XxeU](https://www.youtube.com/watch?v=Sige0y8XxeU), and August [-jVXCHcCoiw](https://www.youtube.com/watch?v=-jVXCHcCoiw). These replace the earlier example sources above. The existing titles, read-more destinations and restored left-column copy were retained; their match to the new footage, rights, geographic access and embed availability must be confirmed before release. No new paid provider or pricing claim is introduced. Incremental recurring vendor fees for this content replacement are **USD $0/month before applicable tax**, assuming unchanged traffic and the same three standard players. No API calls, services, storage products or transaction charges are added. The scenarios, exclusions, alternative outbound-link approach and monitoring/fallback recommendations below remain applicable; video length and quality can change visitor transfer, which remains unmeasured. Editorial review/maintenance effort is unquoted. Runtime playback checks and PDF regeneration remain deferred under instance policy.

A player load means loading one iframe, not watching an entire video. Updated planning assumptions are unmeasured, assume every visitor reaches all three lazy-loaded players, and exclude repeat loads, caching, player scripts, player-generated previews, ads and media segments. Player loads = page loads × 3. The site no longer requests separate archive thumbnail images; previews inside YouTube's players still generate third-party traffic. Actual requests and bytes are higher and variable.

| Scenario | Page loads/month | Player loads/month | Separate site-requested thumbnails/month | Added configured video-service fees/month |
| --- | ---: | ---: | ---: | ---: |
| Low | 1,000 | 1,000 × 3 = 3,000 | 0 | $0 |
| Expected | 10,000 | 10,000 × 3 = 30,000 | 0 | $0 |
| Heavy | 100,000 | 100,000 × 3 = 300,000 | 0 | $0, availability not guaranteed |

The incremental recurring vendor subtotal for this follow-up remains **USD $0/month before applicable tax**, assuming the existing standard-player setup and unchanged hosting. Two additional players can increase visitor transfer and browser work; YouTube, not our host, serves that media. No Data API, paid account, subscription, compute, storage product or transaction charge is added. Keeping archive previews with outbound links would be simpler and lighter but would not meet the new in-page video request. Existing commercial eligibility, geographic/owner restrictions and removal risks remain; no new unit-price offer or allowance is claimed. Monitor playback failures and actual site transfer in the pilot; read-more links and the player's own YouTube controls are the remaining fallback, with no promise that blocked content will play externally. Existing labor, hosting/domain, tax and currency-conversion exclusions still apply; no new paid commitment is required.

YouTube serves video and preview bytes directly; our site adds only text, markup and CSS. No new compute, database, storage product, transaction charges or paid image service is configured. Site bandwidth/storage remains dependent on the unselected host. Domain, taxes, currency conversion, implementation, monthly curation, licensing clearance and maintenance remain excluded/unquoted. This is not the full operating budget; existing map/font forecasts remain applicable.

**Commercial eligibility and limits:** embedding is not ownership of footage or permission to rehost it. The reviewed terms restrict selling advertising around YouTube content where it is the primary basis for sales; no sponsorship or advertising placement was added. Confirm purchaser jurisdiction, video rights and target audience before commercial launch. No Vietnam availability guarantee is inferred. Owners can remove videos or disable embedding; geographic/age restrictions, network blocking or missing referrer information can prevent playback rather than trigger paid automatic overage. The iframe preserves an origin referrer to avoid YouTube error 153. Privacy-enhanced mode does not mean no third-party connections or no ads; thumbnails also contact YouTube. Review consent/privacy notice requirements before release.

The cheaper/simpler alternative is the former text/illustration feature or outbound video links only: no embedded player requests and fewer privacy/availability dependencies, but no in-page viewing. Self-hosting rights-cleared video could offer more control, but requires licensing, storage, delivery bandwidth and maintenance estimates and is not implemented. Monitor playback failures and host transfer during a pilot; after the latest simplification, read-more links and the player's own YouTube controls remain the fallback when embedding fails. Remove unavailable picks manually. Hosting budget alerts are not hard caps. No new paid vendor commitment is required for the prototype.

**Layout follow-up:** the desktop columns now use a 2:1 ratio (current feature twice the archive width), with a 1,440-pixel section maximum and gold editorial sublines. This supersedes the equal-width layout above; mobile stacking remains unchanged. This CSS-only adjustment adds no assets, services, subscriptions, API calls, storage products or transaction fees. Incremental recurring vendor subtotal is **USD $0/month before applicable tax**, assuming the same traffic and hosting; vendor-fee estimates remain zero in the updated low/expected/heavy scenarios above. A larger player may cause YouTube to choose a higher-quality stream, so visitor transfer can vary, but no video bytes are served by our host. Retaining equal columns is the simpler rollback option but does not meet the updated design request. Existing commercial/availability conditions, monitoring and fallbacks still apply; no new price claim or paid decision is involved. Implementation/maintenance labor, hosting, domains, taxes and currency conversion remain excluded/unquoted.

Validation and PDF regeneration/visual inspection remain deferred under the instance execution policy. On a capable development machine, run `npm run check`, `npm run build`, and `uv run --with reportlab python scripts/build-billing-brief.py`; visually inspect the regenerated PDF and desktop/mobile layout, and test actual video playback in the release environment. The PDF status at the top remains applicable until then.

## Delivered follow-up: district directory and map story panel

The discovery map now uses a **1:2 desktop layout**: district directory on the left, existing Leaflet map on the right. Selecting a curated place from a map pin or district entry replaces the directory with a video, place title, description and detail-page link. Back restores the directory and stops the video; selecting another place replaces the previous player. Search/category/distance filters apply to directory links as well as pins; an excluded selection closes. The layout stacks on smaller screens. The illustrated fallback also opens the story panel, while destination links remain available without JavaScript.

**Content scope:** the directory contains 30 former district-level areas (12 urban districts, 17 rural districts and Sơn Tây), explicitly labeled historical rather than current administrative units. [Hanoi's official account of the July 2025 administrative change](https://hanoi.gov.vn/videos/ha-noi-cong-bo-nghi-quyet-sap-xep-don-vi-hanh-chinh-van-hanh-chinh-quyen-hai-cap-tu-1-7-2025-425063022371804.htm) and the [former 30-area arrangement](https://quydautuphattrien.hanoi.gov.vn/ban-tin/phuong-an-chi-tiet-sap-xep-30-quan-huyen-thi-xa-cua-ha-noi-380.html) were consulted October 16, 2026. Only the existing six destinations are mapped; empty districts are marked as having no curated content. This is an editorial directory, not district-boundary mapping or a complete places database. Each story uses the existing [Vietnam Tourism My Ha Noi overview](https://vietnam.travel/things-to-do/my-hanoi), labeled as a city overview, not destination-specific footage. Destination-specific video production/selection remains unquoted future content work.

**Recommendation and decision:** retain the prototype's Leaflet/public OSM tiles and standard YouTube player; no Mapbox account, paid geocoding, boundary API, routing API, CMS or new dependency was introduced. Incremental configured recurring vendor subtotal is **USD $0/month before applicable tax**, assuming the same static hosting and standard embedding setup. No new subscription, Data API calls, backend compute, database, video-storage product, image service or transaction fees are configured. The HTML adds six inert story templates: video requests begin only when a story is selected, with at most one map-story player attached at a time. This is in addition to the separate three editorial players, whose earlier forecasts remain applicable.

The [primary OSM tile policy](https://operations.osmfoundation.org/policies/tiles/) and [YouTube embedding guide](https://support.google.com/youtube/answer/171780?hl=en) were rechecked October 16, 2026. OSM offers no published numeric tile allowance or commercial availability guarantee; access can be blocked without notice rather than trigger a paid automatic upgrade. Browser caching, visible attribution, HTTPS and referrer headers remain; no offline download/prefetch was added. The guide supports the standard/privacy-enhanced player and warns of owner-disabled embeds, age restrictions and required referrer headers. Neither source supplies a new metered unit-price quote for this setup; $0 is our configured vendor-fee estimate, not a guaranteed unlimited allowance. Existing YouTube commercial/privacy conditions above remain applicable; commercial rights, audience/jurisdiction and Vietnam playback availability need release review.

**Updated map-interaction forecasts (unmeasured):** a map opening is one initialization, not a unique user. A tile request fetches one small map image. A story selection creates one video player; repeated selections count again even if media is cached. The narrower but taller viewport and pin-centering can alter tile demand. Conservatively retain 24 requests/opening for low/expected scenarios and 60 for heavy exploration, including assumed interaction; measure rather than treat these as quotas.

| Scenario | Map openings/month | Tile requests/month | Assumed story selections/opening | Additional story-player loads/month | Configured map/video vendor subtotal/month |
| --- | ---: | ---: | ---: | ---: | ---: |
| Low | 1,000 | 1,000 × 24 = 24,000 | 0.25 | 1,000 × 0.25 = 250 | $0 |
| Expected | 10,000 | 10,000 × 24 = 240,000 | 0.5 | 10,000 × 0.5 = 5,000 | $0 |
| Heavy | 100,000 | 100,000 × 60 = 6,000,000 | 2 | 100,000 × 2 = 200,000 | $0, service can be blocked |

These are demand assumptions, not measured bills or suitable guaranteed public-OSM production volumes. Player scripts, previews, ads and media segments add variable third-party requests/bytes. OSM and YouTube serve those assets; our host serves only the expanded static HTML/CSS/JavaScript. Public hosting/storage/bandwidth pricing and limit/overage behavior remain unknown until a host is selected. Domains, tax, currency conversion, implementation, video rights/production, content curation and maintenance labor remain excluded/unquoted. This subtotal is not the full business cost.

The simpler alternative is the old full-width map linking to existing detail pages: less inline content/player demand, but not the requested browsing experience. A static directory/illustrated map avoids tile dependence but lacks live geographic detail. A paid map supplier is still a proposed reliability alternative requiring refreshed eligibility, Vietnam coverage and traffic-based pricing before commitment; no paid option is silently selected. Monitor actual tile counts, map/video errors and host transfer in a pilot. Keep the illustrated fallback, retry button, video viewing/source link and place-page link. Configure supported hosting/provider budget controls before paid deployment; alerts are not hard spending caps. No additional paid commitment is required for this prototype change.

Source review and district-data tests were authored, but tests, application checks, browser interactions/playback, and PDF generation/visual inspection were not executed under the instance resource policy. On a capable development machine run `npm run test`, `npm run check`, `npm run build`, and `uv run --with reportlab python scripts/build-billing-brief.py`. Check live and fallback pin selection, keyboard activation/Back, filter changes, video teardown, empty districts, mobile stacking, preserved map attribution and the regenerated PDF. The PDF status above remains applicable.

## Proposed: Contemporary Travel Editorial redesign — awaiting approval

October 17, 2026: Phase A source/asset review proposes a lighter treatment of the existing incense photograph, Newsreader display typography with Be Vietnam Pro supporting text, an ivory/ink editorial system, rights-cleared video covers linking to the unchanged YouTube videos, and a restyled functional Leaflet discovery interface. No application code has been changed for this proposal. Browser inspection, screenshots and reproduction of the reported tile failure are unavailable in this session; this is not a visually verified implementation or confirmed map fix.

**Recommendation and decision:** approve the visual direction before implementation; retain the static architecture and existing integrations. Do not purchase a tile plan or imagery on the strength of this estimate. Three story-specific editorial covers are missing; their acquisition/production and commercial rights are unquoted. No unrelated photographs should be substituted. Retain existing content, routes, data, filtering, geolocation, video URLs and map interactions.

**Expected incremental recurring subscription/API subtotal: USD $0/month before applicable tax**, conditional on no new paid supplier, unchanged hosting contract and rights-cleared local assets. This is not the full business cost or a guarantee of unchanged hosting charges. One-time design/engineering, content licensing/production, maintenance, domains, hosting storage/transfer, taxes and currency conversion are excluded/unquoted. No backend compute, database, transactions or self-hosted video is proposed. Outbound video covers would remove the three editorial iframe loads; the map-story player remains unless separately approved. YouTube availability and third-party commercial terms still apply.

| Unmeasured scenario | Monthly page loads | Added configured subscription/API fee | Additional local cover/font transfer |
| --- | ---: | ---: | --- |
| Low | 1,000 | $0 | 1,000 × B ÷ 1,000,000,000 GB |
| Expected | 10,000 | $0 | 10,000 × B ÷ 1,000,000,000 GB |
| Heavy | 100,000 | $0 | 100,000 × B ÷ 1,000,000,000 GB |

B means the total additional cover/font bytes downloaded per uncached visit; final files are not selected, so no numeric bandwidth forecast is defensible yet. Caching and responsive image selection change actual transfer. Local fonts trade external font connections for our host's storage/transfer; they do not eliminate bandwidth. Existing map demand assumptions remain provisional: openings × 24 tiles for low/expected and × 60 for heavy exploration; changed viewport dimensions must be measured. These are not public OSM quotas.

Primary sources checked October 17, 2026: Google Fonts' [Newsreader metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/newsreader/METADATA.pb) identifies Vietnamese coverage and OFL licensing; [Be Vietnam Pro metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/METADATA.pb) identifies its OFL licensing. The [Newsreader license](https://raw.githubusercontent.com/google/fonts/main/ofl/newsreader/OFL.txt) and [Be Vietnam Pro license](https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/OFL.txt) permit embedding/redistribution subject to retaining notices and license conditions, rather than a recurring font fee. Confirm the selected files' Vietnamese glyphs visually before release. No geographic delivery guarantee is inferred from a font license.

The [OSM tile policy](https://operations.osmfoundation.org/policies/tiles/) was rechecked October 17, 2026: the configured HTTPS endpoint is correct; web requests need an accurate Referer, browser identification, ordinary caching and visible attribution. Public tiles offer no SLA or guaranteed numeric allowance; access can be blocked without notice, not automatically upgraded for a fee. A provider change requires a verified production failure/eligibility assessment and a refreshed quote; earlier paid prices in this document are not newly verified by this proposal. Inspect deployment headers, CSP and actual failed requests before choosing a remedy. Do not hide errors or use the illustrated fallback as the claimed fix.

**Alternatives and controls:** keeping the current design avoids new asset work but retains its editorial weaknesses. Restyling with the current fonts and owner-supplied covers is simpler and avoids font acquisition; the proposed licensed fonts better support the original identity. A paid tile service can improve contractual reliability but adds supplier dependence and needs current commercial/Vietnam eligibility, quotas and overage checks before selection. Monitor tile failures/request counts and delivered asset bytes; configure supported host/provider budget alerts and spending controls if available. Alerts are not hard caps. Preserve destination links and honest retry/error messaging during outages; the live map remains required.

Only this cost record is updated at the approval stage. PDF regeneration/layout inspection remain pending under the instance resource policy; the existing PDF is already stale and must not be shared as this proposal. On a capable machine run `uv run --with reportlab python scripts/build-billing-brief.py`, then `pdftoppm -scale-to 1400 -png output/pdf/ha-long-billing-brief.pdf /tmp/ha-noi-billing` and visually inspect every page. Recalculate transfer and refresh supplier pricing before release or a paid commitment.

## Sprint 01 implemented source: hero and Heritage editorial (browser acceptance pending)

October 17, 2026: the owner authorized implementation of **Nordic Editorial Structure × Vietnamese Cultural Luxury**, limited to shared tokens, header, hero and Heritage video presentation. This supersedes the earlier proposal for these sections only; no discovery-map redesign is included. Lora and Be Vietnam Pro support the scoped editorial system; legacy fonts remain for untouched sections. The original local incense photograph is retained, with a mild shadow-lifting tone curve, a lighter text-only gradient, and independent mobile composition. Heritage uses an asymmetrical layout and native video dialogs with players created only after activation, not three initial embedded players. Existing titles, issue dates, summaries, video IDs and read-more destinations are unchanged.

**Recommendation / decision:** retain the current static setup; no paid vendor commitment is needed. Source implementation is not browser acceptance. Three approved, high-resolution, text-free story covers are still missing; the live cards honestly label temporary typographic covers, not unrelated photographs. The inspected original video thumbnails contain text/collages and suggest mismatches with the existing titles (especially September and August). Editorial approval of associations and still-image rights is required before public release; no replacement content or licensing price has been invented.

**Incremental configured subscription/API subtotal: USD $0/month before applicable taxes**, assuming unchanged traffic, hosting arrangement and standard YouTube embedding. No paid APIs, transactions, backend compute, database, image service or self-hosted video were added. This is not the full business cost: public hosting/storage/bandwidth and limits remain unselected/unquoted; domains, taxes, currency conversion, one-time engineering, photo clearance/production and ongoing curation/maintenance labor are excluded. The unchanged hero remains 1,221,811 bytes; current fallback covers add markup/CSS, not image downloads. New font-file transfer is browser/language/cache dependent and unmeasured.

A player opening below means creating one editorial iframe after a click, not a complete video view or a billable API request. These forecasts replace the previous three-players-per-page assumptions for Heritage only; map-story players and map demand remain unchanged.

| Unmeasured scenario | Page loads/month | Assumed proportion opening video | Openings per engaged visit | Editorial player openings/month | Added configured subscription/API fee/month |
| --- | ---: | ---: | ---: | ---: | ---: |
| Low | 1,000 | 10% | 1 | 1,000 × 0.10 × 1 = 100 | $0 |
| Expected | 10,000 | 10% | 1 | 10,000 × 0.10 × 1 = 1,000 | $0 |
| Heavy | 100,000 | 50% | 2 | 100,000 × 0.50 × 2 = 100,000 | $0, availability not guaranteed |

YouTube serves player/media bytes. Site-host transfer for eventual local covers is `page loads × B ÷ 1,000,000,000` decimal GB, where B is the combined delivered cover bytes per uncached visit; B is currently zero because approved photographs are absent. Re-estimate when assets are supplied. Font traffic and HTML/CSS/JavaScript are additional; this is not a numeric hosting bill or free hosting quota.

Primary sources rechecked October 17, 2026: [Lora metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/lora/METADATA.pb) explicitly lists Vietnamese; [Be Vietnam Pro metadata](https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/METADATA.pb), [Lora OFL](https://raw.githubusercontent.com/google/fonts/main/ofl/lora/OFL.txt) and [Be Vietnam Pro OFL](https://raw.githubusercontent.com/google/fonts/main/ofl/bevietnampro/OFL.txt) identify open font licensing permitting use/embedding subject to license conditions, with no recurring font license fee. This does not guarantee Google-hosted font availability in Vietnam. System fallbacks remain; Vietnamese glyphs still require visual inspection. No new paid provider price is asserted.

The [YouTube embedding guide](https://support.google.com/youtube/answer/171780?hl=en), rechecked October 17, 2026, documents privacy-enhanced players, owner-disabled embeds, restrictions and required referrers. It does not supply a metered embed-view allowance, paid overage schedule or commercial/geographic availability guarantee. Existing commercial/privacy review remains necessary; a standard player is not a license to extract or rehost stills. Blocking, removal and owner restrictions can interrupt viewing, not automatically incur paid upgrades. Each dialog retains an original YouTube link as a fallback, without promising external playback if the source itself is restricted.

**Alternatives and controls:** outbound-only links are simpler and avoid iframe requests but lose in-page viewing. Retaining the former three players is a rollback option but restores initial third-party loading and black-player presentation. Self-hosted video is not selected and would require rights and a delivery quote. Monitor actual font/image failures, video failures, delivered asset bytes and eventual host usage; apply supported spending controls before paid deployment. Alerts are not hard spending caps. No paid service is approved by this sprint.

The owner authorized the dev server and browser QA; the local Astro preview responds, but this session has no browser or screenshot tooling. Desktop/mobile visual acceptance, playback/focus testing, before/after screenshots and PDF regeneration/visual inspection remain pending. This implementation is **not release-ready** until those checks and asset/content issues are resolved. PDF generation remains deferred under the instance resource policy; the stale PDF notice at the top still applies. See `output/sprint-01/QA.md` for the checkpoint, preview, limitations and acceptance steps.

## Delivered follow-up: temporary Heritage photographs

October 17, 2026: the three owner-attached JPEGs replace the Heritage section's grey typographic covers only. Autumn foliage is assigned to the featured entry, the cốm/fruit tray to September and the overhead tea/lotus-seed setting to August. Existing story titles, video IDs, links, layout and modal behavior are retained. Every cover visibly states that it is temporary pending approval of original editorial stills. This supersedes the missing-cover/zero-image-bytes statements above, not the unresolved editorial associations. Production-video ownership is confirmed by the owner; no video downloads, frame extraction, generated images or paid asset purchases were needed.

**Recommendation / decision:** use these local temporary assets for review, then replace them with approved editorial originals. Incremental configured subscription/API subtotal remains **USD $0/month before applicable taxes**, assuming unchanged hosting and traffic. No API, image service, compute, database, subscription or transaction fee was added; no new provider rate is asserted. Public hosting/storage/transfer remains unselected and unquoted. Domains, taxes, currency conversion, implementation, rights/approval review and maintenance labor remain excluded: this is not a full business operating cost.

The three unchanged attached JPEGs add **1,292,139 bytes** of published storage (649,269 + 245,951 + 396,919). Assuming every visit scrolls to and downloads all three lazy-loaded covers once, without caching:

| Unmeasured scenario | Visits/month | Additional image requests/month | Image-only transfer calculation | Transfer/month |
| --- | ---: | ---: | --- | ---: |
| Low | 1,000 | 1,000 × 3 = 3,000 | 1,292,139 × 1,000 ÷ 1,000,000,000 | 1.29 GB |
| Expected | 10,000 | 10,000 × 3 = 30,000 | 1,292,139 × 10,000 ÷ 1,000,000,000 | 12.92 GB |
| Heavy | 100,000 | 100,000 × 3 = 300,000 | 1,292,139 × 100,000 ÷ 1,000,000,000 | 129.21 GB |

These are demand forecasts, not guaranteed bills or a free bandwidth allowance. Caching and lazy loading can reduce transfer; headers, hero, fonts, HTML, map requests and YouTube media are excluded. The simpler/lighter alternative is retaining the labeled grey fallback; compressed responsive derivatives are a future optimization, not implemented. Monitor bytes served and image failures, retain the existing image-error fallback, and confirm hosting quotas/overage or suspension behavior before public release. No paid limit is newly configured; budget alerts are not hard caps. Recalculate after original stills or hosting are selected.

Browser decoding/crop/interaction verification and PDF regeneration remain pending under the instance resource policy. For local review use `http://localhost:4321/`; on a browser-capable machine verify all three images at desktop/mobile sizes and preserved modal behavior. A lightweight HTTP check can use `curl -I http://localhost:4321/images/heritage-temporary-autumn.jpg` (repeat for `heritage-temporary-com.jpg` and `heritage-temporary-tea.jpg`). PDF commands remain `uv run --with reportlab python scripts/build-billing-brief.py` followed by `pdftoppm -scale-to 1400 -png output/pdf/ha-long-billing-brief.pdf /tmp/ha-noi-billing` and visual inspection; neither was executed here. The stale-PDF notice still applies.

## Delivered follow-up: verified Heritage metadata and focused polish

October 17, 2026: one static record per video now supplies its exact Vietnamese YouTube title, verified full description, description-derived excerpt, actual displayed publication date, thumbnail metadata, existing supplied cover and original video link. This supersedes the sample issue dates, incorrect titles/descriptions and unrelated read-more destinations above. The three publication dates are 11 September 2026, 25 August 2026 and 14 June 2026 respectively. Approval status for the same temporary covers is retained internally, not publicly labeled. Only Heritage play-control consistency, date legibility, headline measure and supporting-story spacing were polished; other sections and cover/image ratios are unchanged.

No YouTube Data API credentials were available. Official YouTube oEmbed and public watch-page metadata were retrieved once during implementation, not at build time or per visitor. The [first video](https://www.youtube.com/watch?v=2CxNZtrFedo&hl=vi), [second video](https://www.youtube.com/watch?v=Sige0y8XxeU&hl=vi), [third video](https://www.youtube.com/watch?v=-jVXCHcCoiw&hl=vi) and their official oEmbed responses were checked October 17, 2026. Full evidence and limitations are in `output/sprint-01/metadata/`. Exact publication/upload timestamps remain unavailable; only day-level publication dates are asserted. The verified YouTube thumbnails are 480 × 360 metadata entries, not new public image requests or substitutes for the supplied covers. Video ownership is confirmed by the owner; approval of original editorial stills remains pending.

**Recommendation / decision:** keep the curated static records and existing video integration; no paid service or purchase decision is needed. Incremental configured recurring subscription/API subtotal is **USD $0/month before applicable tax**, assuming unchanged traffic, hosting and assets. Low/expected/heavy scenarios of 1,000/10,000/100,000 visits each add **0 runtime metadata API requests × $0 = $0/month**. This is a configuration-based zero-fee conclusion, not a quoted Data API unit price or guaranteed supplier allowance. Earlier image-transfer forecasts remain 1.29/12.92/129.21 GB for those scenarios, assuming every visitor downloads the same three covers uncached. No new compute, storage product, database, transaction fee, font service or paid image/video service was added. Static text/markup bytes change slightly; whole-site transfer remains unmeasured.

The simpler alternative is keeping the prior static text but it would retain known factual errors; automated API refresh is not implemented and would need a separate eligibility/quota/terms and maintenance review before commitment. Manual verification requires unquoted curation time. Public hosting/storage/bandwidth, domains, taxes, currency conversion, implementation, still-image rights/approval and maintenance labor remain excluded/unquoted; this subtotal is not the full business cost. Provider blocking/removal and host-limit behavior remain unchanged. Preserve original-video and image-error fallbacks, monitor playback/image failures and delivered bytes, and refresh records when the owner changes videos. Alerts are not hard spending caps. No new paid pricing claim is made.

Source review only: no browser visual/playback QA, application checks/build/tests or PDF generation were run under the instance resource policy. On a capable machine use `npm run check`, then `npm run dev -- --background` for desktop/mobile inspection and interaction testing. Regenerate/visually inspect the billing PDF with the commands in the preceding entry before sharing it as current. Its stale notice still applies.

## Runtime repair: separate map and editorial video contracts

October 17, 2026: fixed the preview crash caused by the map's six inert story templates still passing `videoId`/`title` to the newly record-based `HeritageVideo`. The map now uses an isolated `MapStoryVideo` with the original iframe markup/styles; the three editorial records, metadata, covers, design and modal behavior are unchanged. This repairs the shared-component contract, not a new map feature or service. Incremental recurring vendor cost is **USD $0/month before tax**, assuming the same traffic/hosting/player behavior. No assets, dependencies, paid API requests, storage service, compute, database or transactions were added. Existing low/expected/heavy forecasts, supplier limits and fallbacks remain applicable; hosting/domains, taxes, currency conversion and repair/maintenance labor remain excluded/unquoted. No new price claim or paid decision is involved. Keeping incompatible props is not a viable alternative; isolating the original player avoids inventing missing editorial records for unrelated map content.

The owner explicitly authorized build/runtime testing for this repair. `mise exec -- npm run build` passed (7 pages); `HERITAGE_PREVIEW_URL=http://localhost:4321/ mise exec -- npm run test` passed (11 tests, none skipped), including complete live/built homepage output, the three correct editorial IDs/links/covers and six inert map players. Browser visual/playback QA and PDF regeneration remain pending; these tests do not verify visual appearance or YouTube playback. This note does not change the billing estimate or make the existing PDF current.

## Delivered follow-up: Heritage column balance and local warm-white background

October 17, 2026: the Heritage wrapper previously inherited `--rice-paper` (#F4F1EB); its component-local background is now #FAF9F6 without changing global colors. Supporting covers use shallower 11:5 desktop frames with `object-fit: cover`, tighter text/story spacing and shorter description-derived editorial excerpts. Mobile retains generous 3:2 frames. The asymmetric grid, photography, verified YouTube titles/full descriptions/dates/thumbnail metadata/URLs and play behavior remain unchanged. No other section is redesigned.

Incremental configured recurring vendor fees are **USD $0/month before tax**, assuming unchanged hosting, traffic and the same delivered assets/player behavior. Low/expected/heavy scenarios of 1,000/10,000/100,000 visits each add zero paid API requests/services × $0 = $0/month. Existing cover-transfer forecasts (1.29/12.92/129.21 GB) and limits/fallbacks still apply; CSS cropping does not reduce downloaded JPEG bytes. No new subscriptions, assets, compute, storage product, database or transaction fee is introduced, and no new supplier price is asserted. Hosting/storage/bandwidth, domains, taxes, currency conversion and implementation/maintenance labor remain excluded/unquoted. Retaining the prior spacing/background is a no-service-cost alternative but leaves the reported imbalance; no paid decision is needed. Monitor existing host usage and media failures; alerts are not hard spending caps. The unchanged estimate does not make the stale PDF current; regeneration/visual inspection remain pending under instance policy.

The owner authorized the build and regression tests for this polish. Browser visual acceptance remains unavailable: automated rendering/link/image checks do not measure actual column balance, crops or typography at desktop/mobile viewports.

## Delivered follow-up: homepage background palette

October 17, 2026: the homepage header (including top/scrolled/mobile states and menu) and Heritage wrapper now use local #F8F7F3 surfaces. The header uses dark text for contrast on its solid background, replacing its transparent top state without changing geometry or typography. The homepage Explorer wrapper changes from inherited `--paper` to #FFFFFF; map tile/panel/control/card fills remain untouched. Global white page background and existing paper tokens are unchanged. #EAE5DA is reserved for later cultural storytelling, not applied globally or to another section now. Heritage layout, verified metadata, photography, interactions and map functionality are unchanged.

Incremental configured recurring vendor fees are **USD $0/month before tax**, assuming unchanged assets, traffic, hosting and request behavior. Low/expected/heavy scenarios of 1,000/10,000/100,000 visits each add zero paid requests/services × $0 = $0/month. No assets, subscriptions, APIs, compute, database, storage product or transaction fees are introduced; no new provider price is claimed. Existing transfer estimates, limits and fallbacks remain applicable. Hosting/bandwidth/storage, domains, taxes, currency conversion and design/maintenance labor remain excluded/unquoted. Retaining the prior colors is an equally service-cost-free alternative but not the requested palette; no paid decision is required. Existing monitoring and host controls remain appropriate; alerts are not hard caps. This small CSS-only change does not alter the estimate or make the stale PDF current; regeneration/visual inspection remain pending under instance policy.

Authorized checks passed: `mise exec -- npm run build` generated 7 pages; `HERITAGE_PREVIEW_URL=http://localhost:4321/ mise exec -- npm run test` passed all 11 tests, none skipped, including live/built homepage rendering and video/image associations. No browser/computed-color or visual QA was performed; automated tests do not prove the rendered palette or contrast.

## Sprint 02A: approved tile-only referrer correction

October 17, 2026: added only `referrerPolicy: 'strict-origin-when-cross-origin'` to the existing Leaflet tile layer. OSM endpoint, attribution, caching, retry behavior, data, layouts and global security policies are unchanged. No proxy, spoofed identity or new service is introduced. Incremental configured recurring vendor fees are **USD $0/month before tax**, assuming unchanged traffic/hosting; low/expected/heavy scenarios each add zero paid services/API requests × $0 = $0/month. Actual successful tile delivery could differ from denied-image delivery, so existing demand assumptions still need measurement, not a guaranteed bill. Hosting/transfer/storage, domains, tax, currency conversion and implementation/maintenance labor remain excluded/unquoted. Existing provider limits, fallback and monitoring guidance remain; alerts are not spending caps. Keeping inherited policy is simpler but retains the reported missing-Referer risk. No paid commitment or new supplier-price claim is involved; this unchanged estimate does not make the stale PDF current.

**Finalized October 17, 2026 — desktop preview issue user-verified resolved.** The owner confirms that the Windows desktop preview displays real geographic tiles and Chrome Network shows the actual preview origin in the outgoing Referer header. This is user-supplied browser verification, not an assistant browser test, cross-device result or production-domain certification. The working map implementation remains byte-for-byte unchanged during finalization. A new source-AST regression check verifies the single existing OSM layer and its exact referrer policy without making tile requests; all previous tests remain intact. The authorized production build passed (7 pages) and the full suite passed (12 tests, none skipped). Frozen Heritage dependency/asset/test checksums match. No additional tile requests, proxy, spoofing, caching changes or automatic retries were introduced. Finalization adds only development-test/documentation/checkpoint work, with USD $0/month incremental configured vendor fees under the assumptions/exclusions above. Stable checkpoint: `output/sprint-02a/verified-checkpoint.tar.gz`. PDF regeneration remains pending; the existing PDF is not newly current.

## Recommended decision

Keep the current free setup for private proof-of-concept reviews. For a public commercial launch, shortlist Stadia Maps Starter for maps, or MapTiler Flex as an alternative. If directions must work inside our site, budget a routing-capable service separately; this brief models Stadia Standard. Check Vietnam map quality, route quality, provider eligibility, and support requirements before selecting a supplier.

At 10,000 monthly map openings, the modeled map-service subtotal is **$20 with Stadia Starter** or **$30 with MapTiler Flex**, even in the heavy-use scenario below. Proposed in-app routing on Stadia Standard is **$80** in the same traffic scenario. These figures exclude labor, domains, taxes, and any future backend costs.

## What exists today

The site has six hardcoded destinations, interactive maps, browser location, filters, and place pages. Distances are straight-line estimates. There is no database, account system, booking, payment, route calculation, or live traffic information. Place-page links open OpenStreetMap at the destination; directions are not implemented.

The current local prototype has **$0 in configured recurring service fees**. Existing development equipment and labor are excluded. Public deployment has not been configured.

## Alternatives at a glance

| Option | Monthly starting price | Business implication |
| --- | ---: | --- |
| Current Leaflet and public OSM tiles | $0 service fee | Suitable for small reviews; shared tile capacity and no uptime guarantee. Not our recommended commercial dependency. [1] |
| Stadia Starter for maps | $20 | 1 million credits; standard tiles use 1 credit each. Extra usage is $0.03 per 1,000 credits when enabled. Commercial use allowed. [2] |
| MapTiler Flex for maps | $30 | 500,000 API requests; extra requests are $0.15 per 1,000. Leaflet uses request billing, not the SDK session allowance. [3] |
| Stadia Standard with routing | $80 | 7.5 million credits; routing uses 20 per request. Overage is $0.02 per 1,000 credits. Proposed integration, not current functionality. [2] |
| Self-hosted maps and routing | Quote required | Server, map updates, monitoring, and staff time replace provider fees. No defensible estimate without a deployment design. |
| Google Maps Platform | Not costed | Vietnam is listed as a prohibited territory under standard terms. Eligibility needs written clarification; overseas hosting alone is not a documented exception. [7][8] |

Leaflet itself has no per-user fee. Provider free plans are not interchangeable: Stadia allows development and demonstration on its free plan, but commercial production needs a paid plan. MapTiler also allows testing and development but excludes ordinary commercial production from its free plan. [4][9]

<!-- pagebreak -->

## Map usage and monthly estimates

A map opening is one page load that starts the interactive map, not one unique customer. A tile is a small image used to draw part of the map. Loading, panning, and zooming can request multiple tiles.

Planning assumptions, not measured usage: **15 billable 256-pixel tiles per opening normally**, and **40 with heavier exploration**. No satellite imagery, address search, routing, or uploaded data is included in this table. Normal browser caching remains enabled; actual paid requests must be measured after a pilot.

| Map openings per month | Stadia normal | Stadia heavy | MapTiler normal | MapTiler heavy |
| ---: | ---: | ---: | ---: | ---: |
| 1,000 | $20 Starter | $20 Starter | $30 | $30 |
| 10,000 | $20 Starter | $20 Starter | $30 | $30 |
| 100,000 | $35 Starter | $80 Standard | $180 | $555 |
| 1,000,000 | $230 Standard | $475 Professional | $2,205 | $5,955 |

Stadia rows select the least expensive of the three published paid tiers modeled here for each map-only workload; tier changes would need to be made. Professional is $250 with 25 million credits and $0.015 per 1,000 extra credits. MapTiler rows keep Flex unchanged; large-volume custom quotes may be cheaper. Prices and limits: [2][3].

## How to reproduce the estimates

Monthly tile requests = map openings multiplied by tiles per opening.

For each plan, monthly charge = base subscription plus the larger of zero or usage above the included allowance, multiplied by the overage price per unit. The calculation assumes overages are enabled and available. Do not add the included allowance again as a separate charge.

For example, 100,000 normal openings create 1,500,000 requests. MapTiler Flex costs $30 plus 1,000,000 extra requests divided by 1,000, multiplied by $0.15: **$180**. At 40 tiles, usage is 4,000,000 requests and the result is **$555**. [3]

## Hosting and excluded costs

Cloudflare Pages is a proposed static-hosting option: static asset requests are free and unlimited; its free tier allows 500 builds per month. The current seven-page static site needs no paid server or database. This adds **$0 to the modeled hosting subtotal** while the site remains static and within platform limits. Server functions have separate billing. [5][6]

The tables are **map-service subtotals**, not full business budgets. A domain name, development, maintenance, content work, taxes, and payment-currency conversion are not quoted. A free provider hostname avoids buying a domain for a pilot. Optional premium support, analytics, dynamic infrastructure, and other new services require a revised estimate.

<!-- pagebreak -->

## Directions and future feature costs

**External directions:** A proposed button could open a navigation app. It would not call a routing API through our account, so the expected incremental routing-vendor fee is $0. Implementation effort remains unquoted. This option moves the visitor away from our site and depends on the selected app's capabilities and terms.

**Directions inside our site:** A routing provider can supply a route line, travel distance, estimated duration, and instructions. This brief budgets Stadia Standard rather than assuming those capabilities are included in a map-only plan. Live traffic, offline navigation, and continuous turn-by-turn guidance are outside this scenario.

Assume 15 tiles per map opening, and 20% of openings request one standard route. Usage is 15 tile credits plus 4 routing credits per opening, or **19 credits per opening**. Using Standard gives the following service-only estimates. [2]

| Monthly map openings | Route requests | Total credits | Stadia Standard subtotal |
| ---: | ---: | ---: | ---: |
| 1,000 | 200 | 19,000 | $80 |
| 10,000 | 2,000 | 190,000 | $80 |
| 100,000 | 20,000 | 1,900,000 | $80 |
| 1,000,000 | 200,000 | 19,000,000 | $310 |

At the largest scenario, Professional's $250 base covers the modeled volume and is cheaper than Standard. This is an alternative plan selection, not an additional subscription. Retries, route recalculation, different travel profiles, and other APIs can change usage. Test Ha Noi routes, pedestrian access, and bridge restrictions; a map pin is not a verified entrance or evidence that a route is safe or permitted.

A secure routing integration may add a small backend or another authentication design. Its hosting and implementation costs must be scoped before calling this a complete directions budget. Routing is proposed, not implemented.

## Other requests from management

| Requested change | Billing assessment needed |
| --- | --- |
| More manually curated destinations or layout changes | Usually no extra service fee under today's static design; estimate content and implementation effort separately. |
| Search addresses or discover live businesses | New search/geocoding/places calls; estimate calls per search and retries, not just visitor count. |
| Accounts, saved trips, or an editing dashboard | Reassess authentication, database, storage, backups, and server functions. |
| Bookings, payments, email, SMS, or AI features | Quote the relevant subscriptions and transaction/message/model usage; no prices are assumed here. |

The alternative with the lowest vendor bill may require more staff time or offer fewer features. Decisions should consider both operating bills and delivery effort.

<!-- pagebreak -->

## Controls and conditions for a decision

Public OSM tiles have no published numeric allowance or guaranteed uptime. Heavy usage can be blocked without notice; there is no automatic paid upgrade. [1]

Stadia's additional usage is opt-in. Treat a plan without extra usage as capped; confirm the resulting service interruption and dashboard settings before launch. MapTiler Flex bills extra use automatically and supports a spending limit; confirm how reaching that limit affects service. Free-tier limits can suspend maps until the next billing period. [2][3][9]

For a pilot, monitor provider-request counts, map openings, routes, and errors. Set alerts at 70% and 90% of the agreed monthly budget. Those alert levels are our recommendation, not provider guarantees. An alert is not a spending cap. Choose explicitly whether crossing a supported limit should stop map requests, serve the illustrated fallback, or permit a budgeted overage.

Before a public launch, management needs to decide:

- Whether visitors need maps only, external directions, or directions within the site.
- The target monthly map openings, expected exploration, and acceptable service interruptions.
- The provider and tier, overage policy, and budget owner.
- Whether to use a free hostname or obtain a separate domain quote.
- The scope and internal effort budget for any new feature.

Current forecasts have **high confidence in the checked public unit rates and arithmetic**, and **low confidence in usage**, which has not been measured. Providers' account eligibility, Vietnam coverage, taxes, and any contractual exceptions must be confirmed for the actual purchaser. Quotes and measured traffic should replace assumptions as they become available. Recheck rates and scope before spending or releasing.

## Sources checked October 14 2026

[1] [OpenStreetMap tile usage policy](https://operations.osmfoundation.org/policies/tiles/) - capacity, attribution, caching, and availability.

[2] [Stadia Maps pricing](https://stadiamaps.com/pricing/) - monthly paid tiers, credit costs, commercial eligibility, and extra usage. Check feature entitlement and account settings before purchase.

[3] [MapTiler Cloud pricing](https://www.maptiler.com/cloud/pricing/) - Flex rates, request versus session billing, overages, and spending limits. Listed prices exclude VAT.

[4] [MapTiler Cloud terms](https://www.maptiler.com/terms/cloud/) - commercial-use limitations of the free plan.

[5] [Cloudflare Pages pricing](https://developers.cloudflare.com/pages/functions/pricing/) - static requests versus server-function charges.

[6] [Cloudflare Pages limits](https://developers.cloudflare.com/pages/platform/limits/) - free-tier builds and platform limits.

[7] [Google Maps Platform terms](https://cloud.google.com/maps-platform/terms) - section 3.2.1(c)(v), standard territorial distribution restriction.

[8] [Google prohibited territories](https://cloud.google.com/maps-platform/terms/maps-prohibited-territories) - Vietnam listing.

[9] [Stadia Maps FAQ](https://stadiamaps.com/faqs/) - demonstration exceptions, prepaid subscriptions, opt-in additional usage, and account billing behavior.

## Keeping this brief current

Every proposed or delivered change must include a billing-impact assessment in this record. Refresh scope, verified rates, scenarios, alternatives, exclusions, and controls when they change. For changes that do not affect vendor billing, record that conclusion rather than inventing a charge. Maintain the PDF from this Markdown source; `AGENTS.md` makes this part of the development workflow.
