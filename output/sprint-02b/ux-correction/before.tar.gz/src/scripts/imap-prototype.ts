import { places, demoLocation, type Category } from '../data/places';
import { findPlaces } from '../lib/explore';
import { selectDestination, sheetHeight } from '../lib/imap-prototype';
import type * as Leaflet from 'leaflet';

const explorer = document.querySelector<HTMLElement>('#prototype-explorer')!;
const search = document.querySelector<HTMLInputElement>('#prototype-search')!;
const story = document.querySelector<HTMLElement>('#prototype-story')!;
const content = document.querySelector<HTMLElement>('#prototype-story-content')!;
const status = document.querySelector<HTMLElement>('#prototype-map-status')!;
const reopen = document.querySelector<HTMLButtonElement>('#prototype-reopen')!;
const close = document.querySelector<HTMLButtonElement>('#prototype-close')!;
const handle = document.querySelector<HTMLElement>('#sheet-handle')!;
const sizeButton = document.querySelector<HTMLButtonElement>('#sheet-size')!;
const templates = new Map(Array.from(document.querySelectorAll<HTMLTemplateElement>('[data-prototype-story]')).map(template => [template.dataset.prototypeStory!, template]));
const directory = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-select-place]'));
const categories = Array.from(document.querySelectorAll<HTMLButtonElement>('[data-prototype-category]'));
const markers = new Map<string, Leaflet.Marker>();
let map: Leaflet.Map | undefined;
let selected: string | undefined;
let category: Category | 'All' = 'All';
let visible = new Set(places.map(place => place.slug));
let previousFocus: HTMLElement | null = null;
let expanded = false;

function syncSelection() {
  for (const button of directory) button.setAttribute('aria-pressed', String(button.dataset.selectPlace === selected));
  for (const [slug, marker] of markers) {
    marker.getElement()?.classList.toggle('is-selected', selected === slug);
    marker.getElement()?.setAttribute('aria-pressed', String(selected === slug));
    marker.setZIndexOffset(selected === slug ? 500 : 0);
  }
}
function stopVideo() {
  content.querySelectorAll('video').forEach(video => { video.pause(); video.removeAttribute('src'); video.load(); });
  // Removing an embedded player tears down playback without calling a third-party API.
  content.replaceChildren();
}
function openPlace(slug: string) {
  const next = selectDestination(selected, slug, visible);
  if (next !== slug || !templates.has(slug)) return;
  if (story.hidden) previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  stopVideo();
  selected = slug;
  content.append(templates.get(slug)!.content.cloneNode(true));
  // Future approved dedicated players must still require an explicit play gesture.
  content.querySelectorAll('video').forEach(video => { video.autoplay = false; });
  story.hidden = false;
  explorer.classList.add('has-story');
  reopen.hidden = true;
  content.scrollTop = 0;
  filter();
  content.querySelector<HTMLElement>('h2')?.focus({ preventScroll: true });
}
function closeStory(restoreFocus = true) {
  stopVideo();
  story.hidden = true;
  explorer.classList.remove('has-story');
  reopen.hidden = !selected;
  // Deliberately preserve selected marker, center, zoom and sheet height.
  if (restoreFocus) {
    const target = previousFocus?.isConnected && !previousFocus.closest('[hidden]') ? previousFocus : reopen;
    target.focus({ preventScroll: true });
  }
}
function filter() {
  visible = new Set(findPlaces(places, search.value, category, demoLocation).map(place => place.slug));
  for (const button of directory) button.closest<HTMLElement>('li')!.hidden = !visible.has(button.dataset.selectPlace!);
  for (const [slug, marker] of markers) {
    if (!map) continue;
    if (visible.has(slug) && !map.hasLayer(marker)) marker.addTo(map);
    if (!visible.has(slug) && map.hasLayer(marker)) marker.remove();
  }
  if (selected && !visible.has(selected)) { closeStory(false); selected = undefined; reopen.hidden = true; }
  for (const button of categories) button.setAttribute('aria-pressed', String(button.dataset.prototypeCategory === category));
  document.querySelector('#prototype-count')!.textContent = `${visible.size} địa điểm`;
  document.querySelector<HTMLElement>('#prototype-empty')!.hidden = visible.size !== 0;
  content.querySelectorAll<HTMLButtonElement>('[data-nearby-place]').forEach(button => {
    button.disabled = !visible.has(button.dataset.nearbyPlace!);
    button.title = button.disabled ? 'Địa điểm ngoài bộ lọc hiện tại' : '';
  });
  syncSelection();
}
for (const button of directory) button.addEventListener('click', () => openPlace(button.dataset.selectPlace!));
content.addEventListener('click', event => {
  const button = event.target instanceof Element ? event.target.closest<HTMLButtonElement>('[data-nearby-place]') : null;
  if (button && !button.disabled) openPlace(button.dataset.nearbyPlace!);
});
close.addEventListener('click', () => closeStory());
reopen.addEventListener('click', () => { if (selected) openPlace(selected); });
document.addEventListener('keydown', event => { if (event.key === 'Escape' && !story.hidden) closeStory(); });
search.addEventListener('input', filter);
for (const button of categories) button.addEventListener('click', () => { category = button.dataset.prototypeCategory as Category | 'All'; filter(); });

function setSheetHeight(height: number) {
  story.style.setProperty('--sheet-height', `${height}px`);
  expanded = height >= window.innerHeight * .7;
  sizeButton.setAttribute('aria-expanded', String(expanded));
  sizeButton.textContent = expanded ? 'Thu gọn ↕' : 'Mở rộng ↕';
}
sizeButton.addEventListener('click', () => setSheetHeight(window.innerHeight * (expanded ? .42 : .85)));
let drag: { id: number; startY: number; height: number } | undefined;
handle.addEventListener('pointerdown', event => {
  if (event.button !== 0 || (event.target instanceof Element && event.target.closest('button'))) return;
  drag = { id: event.pointerId, startY: event.clientY, height: story.getBoundingClientRect().height };
  handle.setPointerCapture(event.pointerId);
});
handle.addEventListener('pointermove', event => {
  if (!drag || drag.id !== event.pointerId) return;
  setSheetHeight(sheetHeight(drag.height, event.clientY - drag.startY, window.innerHeight));
});
function endDrag(event: PointerEvent) {
  if (!drag || event.pointerId !== drag.id) return;
  if (handle.hasPointerCapture(event.pointerId)) handle.releasePointerCapture(event.pointerId);
  drag = undefined;
  if (story.getBoundingClientRect().height < 190) closeStory();
}
handle.addEventListener('pointerup', endDrag);
handle.addEventListener('pointercancel', () => { drag = undefined; });
window.addEventListener('resize', () => {
  if (story.style.getPropertyValue('--sheet-height')) setSheetHeight(sheetHeight(story.getBoundingClientRect().height, 0, window.innerHeight));
});

function resetView() {
  map?.fitBounds(places.map(place => [place.coordinates.lat, place.coordinates.lng] as Leaflet.LatLngTuple), { padding: [48, 48], maxZoom: 14 });
}
document.querySelector('#prototype-reset')!.addEventListener('click', resetView);
async function connect() {
  try {
    const L = await import('leaflet');
    map = L.map('prototype-map', { scrollWheelZoom: false, zoomControl: false });
    L.control.zoom({ position: 'topright', zoomInTitle: 'Phóng to', zoomOutTitle: 'Thu nhỏ' }).addTo(map);
    const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      referrerPolicy: 'strict-origin-when-cross-origin',
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap contributors</a>',
    });
    tiles.on('tileload', () => { status.textContent = 'Chọn ghim để mở câu chuyện · Kéo để khám phá'; });
    tiles.on('tileerror', () => { status.textContent = 'Một phần nền bản đồ chưa tải được. Ghim và danh sách vẫn hoạt động.'; });
    resetView();
    places.forEach((place, index) => {
      const pin = document.createElement('span'); pin.className = 'curated-pin'; pin.textContent = String(index + 1).padStart(2, '0');
      const label = document.createElement('span'); label.textContent = place.name;
      const marker = L.marker([place.coordinates.lat, place.coordinates.lng], {
        title: place.name, icon: L.divIcon({ className: 'curated-icon', html: pin, iconSize: [42, 42], iconAnchor: [21, 21] }),
      }).bindTooltip(label, { direction: 'top' });
      marker.on('click', () => openPlace(place.slug));
      marker.on('add', () => { marker.getElement()?.setAttribute('aria-label', `Mở câu chuyện ${place.name}`); syncSelection(); });
      markers.set(place.slug, marker); marker.addTo(map!);
    });
    tiles.addTo(map);
    const observer = new ResizeObserver(() => {
      // Preserve geographic camera while desktop columns resize; mobile sheet is an overlay.
      if (!map) return;
      const center = map.getCenter(); const zoom = map.getZoom();
      map.invalidateSize({ pan: false }); map.setView(center, zoom, { animate: false });
    });
    observer.observe(document.querySelector('#prototype-map')!);
    window.addEventListener('pagehide', event => {
      content.querySelectorAll('video').forEach(video => video.pause());
      if (!event.persisted) { observer.disconnect(); stopVideo(); map?.remove(); map = undefined; }
    });
    filter();
  } catch {
    status.textContent = 'Không tải được bản đồ. Chọn địa điểm trong danh sách để tiếp tục.';
  }
}
filter(); void connect();
