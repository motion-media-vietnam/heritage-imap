import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { probePrototypeInitialization } from './fixtures/prototype-init-runtime.mjs';

const source = readFileSync(new URL('../src/scripts/imap-prototype.ts', import.meta.url), 'utf8');

test('real Leaflet circle readiness reproduces the pre-repair initialization failure', async () => {
  const start = source.indexOf('async function connect()');
  const seed = source.indexOf('map.setView(', start);
  assert(seed > start, 'the repaired connect must initialize its view');
  const end = source.indexOf(';', seed) + 1;
  const withoutInitialView = source.slice(0, seed) + source.slice(end);
  const result = await probePrototypeInitialization(withoutInitialView);
  assert.deepEqual(result.container, { x: 960, y: 640 });
  assert(result.errors.some(error => error.includes('layerPointToLatLng')));
  assert.equal(result.tileLayerAdds, 0);
  assert.equal(result.filterCalls, 0);
  assert.equal(result.retryOffered, true);
  assert.equal(result.initializationCompleted, false);
});

test('initial view makes real circle projection/bounds ready before tiles and default filtering', async () => {
  // Controlled dimensions, NOT measured browser/mobile layout or rendered images.
  for (const [width, height] of [[960, 640], [360, 360], [390, 440], [430, 500]]) {
    const result = await probePrototypeInitialization(source, { width, height });
    assert.deepEqual(result.errors, []);
    assert.equal(result.viewCalls, 1);
    assert.equal(result.fitCalls, 1);
    assert.equal(result.fittedBounds.length, 2);
    assert.equal(result.tileLayerAdds, 1);
    assert.deepEqual(result.markerCandidates, ['ho-hoan-kiem', 'pho-co']);
    assert.equal(result.retryOffered, false);
    assert.equal(result.initializationCompleted, true);
  }
});

test('repaired initialization preserves every discovery-radius result without duplicate tile layers', async () => {
  for (const [radius, count] of [[500, 1], [1000, 2], [2000, 5], ['All', 6]] as const) {
    const result = await probePrototypeInitialization(source, { radius });
    assert.deepEqual(result.errors, []);
    assert.equal(result.tileLayerAdds, 1);
    assert.equal(result.markerCandidates.length, count);
    assert.equal(result.initializationCompleted, true);
  }
});
