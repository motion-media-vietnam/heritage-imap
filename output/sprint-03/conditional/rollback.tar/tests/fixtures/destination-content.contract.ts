/** Compile-only tests for the proposed contract. No destination/media records. */
import type {
  DestinationCatalog,
  DestinationRecord,
  DestinationVideo,
  MediaState,
  PublishedDestination,
  Verified,
} from '../../docs/architecture/destination-content.schema.ts';

declare const draft: DestinationRecord<'van-mieu'>;
declare const catalog: DestinationCatalog;
declare const video: DestinationVideo<'van-mieu'>;
declare const pending: Extract<MediaState<typeof video>, { status: 'pending-verification' }>;
declare const published: PublishedDestination<'van-mieu'>;

// @ts-expect-error draft media is not automatically eligible for publication
const cannotPublishDraft: PublishedDestination<'van-mieu'> = draft;
// @ts-expect-error a missing asset cannot acquire playable metadata
const noPlayableMissingAsset: MediaState<typeof video> = { status: 'missing', asset: video };
// @ts-expect-error pending candidates cannot be treated as verified playable assets
const cannotPlayCandidate: typeof video = pending.asset;
// @ts-expect-error a generic Hanoi overview is not an accepted destination-video scope
const noOverview: typeof video.scope = 'city-overview';
// @ts-expect-error portrait media is not accepted for this landscape contract
const noPortrait: typeof video.aspectRatio = [9, 16];
// @ts-expect-error the catalog's media ID must match its destination key
const noCrossDestinationVideo: typeof catalog['ho-tay']['video'] = { status: 'verified', asset: video, approval: published.video.approval };
// @ts-expect-error optional practical facts must carry evidence, not bare copy
const noUnverifiedAddress: NonNullable<typeof draft.practical>['address'] = 'unverified';
// @ts-expect-error verified facts require a non-empty official evidence list
const noEmptyEvidence: Verified<string> = { status: 'verified', value: '', verification: { checkedOn: '2026-10-19', checkedBy: '', sources: [] } };
// @ts-expect-error a video-first published record cannot expose prototype notes
published.prototypeNotes;

const playable: DestinationVideo<'van-mieu'> = published.video.asset;
const sameId: 'van-mieu' = catalog['van-mieu'].id;
void [cannotPublishDraft, noPlayableMissingAsset, cannotPlayCandidate, noOverview, noPortrait,
  noCrossDestinationVideo, noUnverifiedAddress, noEmptyEvidence, playable, sameId];
