/** Pixel geometry for the isolated prototype; no geographic records or UI styling. */
export interface PrototypeFitOptions {
  paddingTopLeft: [number, number];
  paddingBottomRight: [number, number];
  maxZoom: number;
  animate: false;
}
export interface PrototypeViewport {
  width: number;
  height: number;
  sheetHeight?: number;
  toolbarBottom?: number;
  bottomOverlayHeight?: number;
  clippedTop?: number;
  clippedBottom?: number;
  clippedLeft?: number;
  clippedRight?: number;
}
const positive = (value = 0) => Number.isFinite(value) ? Math.max(0, value) : 0;

/** 24px marker half-size + 12px breathing room, plus attribution above the sheet. */
export function prototypeFitPadding(view: PrototypeViewport): PrototypeFitOptions | undefined {
  if (!Number.isFinite(view.width) || !Number.isFinite(view.height) || view.width <= 0 || view.height <= 0) return;
  const left = positive(view.clippedLeft) + 36;
  const right = positive(view.clippedRight) + 36;
  const top = Math.max(positive(view.clippedTop) + 36, positive(view.toolbarBottom) + 36);
  const bottom = Math.max(positive(view.clippedBottom) + 36,
    positive(view.sheetHeight) + positive(view.bottomOverlayHeight ?? 20) + 36);
  // Do not issue an invalid fit/pan when almost the entire map is obstructed.
  if (view.width - left - right < 2 || view.height - top - bottom < 2) return;
  return { paddingTopLeft: [left, top], paddingBottomRight: [right, bottom], maxZoom: 16, animate: false };
}

/** Minimal pixel pan, without changing zoom; undefined means already visible/impractical. */
export function prototypeMarkerPan(point: { x: number; y: number }, size: { x: number; y: number }, padding: PrototypeFitOptions | undefined): [number, number] | undefined {
  if (!padding || !Number.isFinite(point.x) || !Number.isFinite(point.y)) return;
  const [left, top] = padding.paddingTopLeft;
  const right = size.x - padding.paddingBottomRight[0];
  const bottom = size.y - padding.paddingBottomRight[1];
  if (right < left || bottom < top) return;
  const dx = point.x - Math.max(left, Math.min(right, point.x));
  const dy = point.y - Math.max(top, Math.min(bottom, point.y));
  if (Math.abs(dx) < .01 && Math.abs(dy) < .01) return;
  const outward = (value: number) => value > 0 ? Math.ceil(value) : Math.floor(value);
  return [outward(dx), outward(dy)];
}

/** Frame bottom is measured from the scroller top, including its scroll offset. */
export function prototypeStoryHeight(handle: number, frameBottom: number, contentBottomPadding: number, sheetBorder: number) {
  return Math.ceil(positive(handle) + positive(frameBottom) + positive(contentBottomPadding) + positive(sheetBorder)) + 2;
}
