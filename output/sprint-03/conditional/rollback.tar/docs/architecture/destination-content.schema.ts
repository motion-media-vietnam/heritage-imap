/** PROPOSED contract only: not imported by the application; no content migration.
 * Dates, URLs, media dimensions, provenance and cross-record links also need
 * runtime validation and human review before a later publishing integration.
 */
import type { Category, Coordinates } from '../../src/data/places.ts';

/** Reuse the six existing slugs as immutable IDs; never derive IDs from titles. */
export type DestinationId =
  | 'ho-hoan-kiem'
  | 'pho-co'
  | 'van-mieu'
  | 'hoang-thanh-thang-long'
  | 'ho-tay'
  | 'cau-long-bien';

export type ISODate = `${number}-${number}-${number}`;
export type HttpsUrl = `https://${string}`;
export type NonEmpty<T> = readonly [T, ...T[]];

export type PrimarySource =
  | Readonly<{ kind: 'official-url'; url: HttpsUrl }>
  | Readonly<{ kind: 'official-document'; reference: string }>;

export interface Verification {
  readonly checkedOn: ISODate;
  readonly checkedBy: string;
  readonly sources: NonEmpty<PrimarySource>;
  readonly reviewAfter?: ISODate;
}

/** Optional practical fields exist only when their own value has evidence. */
export interface Verified<T> {
  readonly status: 'verified';
  readonly value: T;
  readonly verification: Verification;
}

export interface MediaApproval {
  readonly checkedOn: ISODate;
  readonly approvedBy: string;
  /** File provenance and destination match, not a city-overview substitution. */
  readonly sourceReference: string;
  /** Rights-clearance document/client approval; an upload alone is not a license. */
  readonly rightsReference: string;
  readonly usageConditions?: string;
  readonly rightsExpireOn?: ISODate;
}

export type MediaState<T> =
  | Readonly<{ status: 'missing' }>
  | Readonly<{ status: 'pending-verification'; candidate: Partial<T> }>
  | Readonly<{ status: 'verified'; asset: T; approval: MediaApproval }>;

export interface DestinationCover<Id extends DestinationId = DestinationId> {
  readonly destinationId: Id;
  readonly src: string;
  readonly alt: string;
  readonly width: number;
  readonly height: number;
  readonly byteSize: number;
  readonly objectPosition?: string;
}

export interface DestinationVideo<Id extends DestinationId = DestinationId> {
  readonly destinationId: Id;
  readonly scope: 'destination-specific';
  readonly source: Readonly<{
    kind: 'original-file';
    src: string;
    mimeType: 'video/mp4' | 'video/webm';
  }>;
  readonly aspectRatio: readonly [16, 9];
  /** Actual encoded dimensions; validate >=1280×720 and 16:9 before approval. */
  readonly width: number;
  readonly height: number;
  readonly durationSeconds: number;
  readonly byteSize: number;
}

export type TicketPrice =
  | Readonly<{ kind: 'free'; conditions?: string }>
  | Readonly<{
    kind: 'priced';
    amount: number;
    /** ISO 4217 code; do not assume VND or infer tax inclusion. */
    currency: string;
    unit: string;
    taxTreatment: 'included' | 'excluded' | 'not-stated';
    conditions?: string;
  }>
  | Readonly<{ kind: 'check-official-source'; note: string }>;

export interface DestinationPracticalInformation {
  readonly address?: Verified<string>;
  readonly openingHours?: Verified<Readonly<{
    timeZone: 'Asia/Ho_Chi_Minh';
    summary: string;
    exceptions?: string;
  }>>;
  readonly ticketPrice?: Verified<TicketPrice>;
  readonly recommendedVisitDuration?: Verified<Readonly<{
    minMinutes: number;
    maxMinutes?: number;
  }>>;
  readonly bestTimeToVisit?: Verified<string>;
  readonly accessibility?: Verified<string>;
  readonly transportAdvice?: Verified<string>;
  readonly officialWebsite?: Verified<HttpsUrl>;
  /** An approved entrance link, distinct from the existing approximate OSM pin. */
  readonly directionsLink?: Verified<HttpsUrl>;
}

export interface DestinationRecord<Id extends DestinationId = DestinationId> {
  readonly id: Id;
  readonly slug: string;
  readonly name: string;
  readonly englishName?: string;
  readonly aliases?: readonly string[];
  readonly category: Category;
  readonly coordinates: Readonly<Coordinates>;
  /** This phase preserves existing approximate coordinates, not entrance claims. */
  readonly coordinateMeaning: 'approximate-editorial-pin';
  readonly introduction: string;
  readonly cover: MediaState<DestinationCover<Id>>;
  readonly video: MediaState<DestinationVideo<Id>>;
  readonly practical?: DestinationPracticalInformation;
  readonly relatedDestinationIds?: readonly DestinationId[];
  /** Most recent record review, never a claim that every optional fact is current. */
  readonly lastVerifiedOn?: ISODate;
  /** Explicitly prototype-only; never display these as verified practical facts. */
  readonly prototypeNotes?: readonly string[];
}

/** Matching key/record/media IDs are enforced when a future catalog is authored. */
export type DestinationCatalog = {
  readonly [Id in DestinationId]: DestinationRecord<Id>;
};

/** Proposed video-first release gate; all current destinations remain drafts.
 * No live application behavior is changed by this type declaration.
 */
export type PublishedDestination<Id extends DestinationId = DestinationId> =
  Omit<DestinationRecord<Id>, 'cover' | 'video' | 'prototypeNotes'> & {
    readonly cover: Extract<MediaState<DestinationCover<Id>>, { status: 'verified' }>;
    readonly video: Extract<MediaState<DestinationVideo<Id>>, { status: 'verified' }>;
  };
